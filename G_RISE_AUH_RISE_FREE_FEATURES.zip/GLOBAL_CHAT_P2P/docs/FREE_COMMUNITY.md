# G-rise: free community app

G-rise has no Premium tier, Business subscription, trial timer, paid feature gate, or advertisements. Core private messaging and the P2P network remain free.

## Implemented in this source update

- Editable personal profile metadata (display name, bio, country, website, status), stored locally on this device.
- Editable business profile metadata (business name, category, description, contact, website), stored locally on this device.
- Local community insights: known peers, current connections, private conversation count, joined groups, message-record count, and unread private message count. These are counts only; message text is not analyzed.
- Existing P2P messaging, groups, encryption, relay, and optional approximate location features are retained.

## Important scope and limitations

Personal and business profile fields are currently local-device profile data. This update does **not** implement signed profile publication/discovery to remote peers, a public business directory, product catalogs, global analytics, or cross-device community statistics. The insights screen explicitly reports local-device scope. These network-wide capabilities require a separately designed signed gossip/DHT profile protocol and anti-spam controls before they can honestly be described as available.

Location sharing remains optional and off by default. Public group messages are not end-to-end encrypted; private group messages use the group's invite key. Peers may observe network metadata such as IP addresses.
