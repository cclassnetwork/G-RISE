from helpers import run
from gcp2p.engine import Engine, EngineError


def test_profile_and_business_profile_persist_and_validate(tmp_path):
    async def go():
        e = Engine(str(tmp_path / "profile"), host="127.0.0.1")
        await e.start()
        await e.create_identity()
        saved = e.update_profile({
            "display_name": "Amina Yusuf", "bio": "Community builder", "country": "Nigeria",
            "business_enabled": True, "business_name": "Amina Foods",
            "business_category": "Food", "business_description": "Local food business"
        })
        assert saved["display_name"] == "Amina Yusuf"
        assert saved["business_enabled"] is True
        assert saved["business_name"] == "Amina Foods"
        with __import__("pytest").raises(EngineError):
            e.update_profile({"bio": "x" * 241})
        await e.stop()
        e2 = Engine(str(tmp_path / "profile"), host="127.0.0.1")
        await e2.start()
        assert e2.profile()["business_name"] == "Amina Foods"
        await e2.stop()
    run(go())


def test_insights_are_local_counts_without_message_content(tmp_path):
    async def go():
        e = Engine(str(tmp_path / "insights"), host="127.0.0.1")
        await e.start()
        await e.create_identity()
        s = e.community_insights()
        assert s["known_peers"] == 0
        assert s["private_conversations"] == 0
        assert "contents are not inspected" in s["scope"]
        await e.stop()
    run(go())
