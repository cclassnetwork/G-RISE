/* G-rise - UI. Talks only to the local engine on this phone (127.0.0.1) through /api/*.
   No data is fetched from, or sent to, any website. */
"use strict";
(function () {
  var TOKEN = (location.pathname.split("/")[2] || "");
  var S = { st: null, peers: [], convs: [], group: [], net: null, settings: null, ident: null, thread: null, es: null };
  var $ = function (id) { return document.getElementById(id); };
  var view = $("view"), toastEl = $("toast"), timers = {};

  /* ---------------------------------------------------------------- helpers */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function api(method, path, body) {
    var opt = { method: method, headers: { "X-GC-Token": TOKEN }, cache: "no-store" };
    if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers["Content-Type"] = "application/json"; }
    return fetch("/api" + path, opt).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { var e = new Error(j.error || ("Error " + r.status)); e.status = r.status; throw e; }
        return j;
      });
    });
  }
  function toast(msg) {
    toastEl.textContent = msg; toastEl.classList.add("show");
    clearTimeout(timers.toast); timers.toast = setTimeout(function () { toastEl.classList.remove("show"); }, 2600);
  }
  function copy(text, what) {
    function done() { toast((what || "Text") + " copied"); }
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(done, fallback); } else { fallback(); }
    function fallback() {
      var t = document.createElement("textarea"); t.value = text; document.body.appendChild(t); t.select();
      try { document.execCommand("copy"); done(); } catch (e) { toast("Copy failed"); }
      document.body.removeChild(t);
    }
  }
  function hue(s) { var h = 0; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360; return h; }
  function avatar(name, peer, state) {
    var d = document.createElement("div"); d.className = "av"; d.style.background = "hsl(" + hue(peer || name) + ",70%,62%)";
    d.textContent = (name || "?").charAt(0).toUpperCase();
    if (state) { var s = document.createElement("span"); s.className = "dot " + state; d.appendChild(s); }
    return d;
  }
  function ago(ts) {
    var d = Math.max(0, Date.now() / 1000 - ts);
    if (d < 45) return "now"; if (d < 3600) return Math.round(d / 60) + " min";
    if (d < 86400) return Math.round(d / 3600) + " h"; return Math.round(d / 86400) + " d";
  }
  function clock(ts) { return new Date(ts * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }); }
  function dayLabel(ts) { return new Date(ts * 1000).toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" }); }
  var STATE_TXT = { online: "Online", checking: "Checking", unreachable: "Unreachable", offline: "Offline" };
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function setView(node, cls) {
    view.className = cls || ""; view.innerHTML = ""; view.removeAttribute("data-k");
    if (typeof node === "string") view.innerHTML = node; else view.appendChild(node);
    view.scrollTop = 0;
  }

  /* ---------------------------------------------------------------- data */
  function loadState() { return api("GET", "/state").then(function (s) { S.st = s; return s; }); }
  function loadPeers() { return api("GET", "/peers").then(function (r) { S.peers = r.peers; }); }
  function loadConvs() {
    return api("GET", "/conversations").then(function (r) {
      S.convs = r.conversations;
      var n = 0; r.conversations.forEach(function (c) { n += c.unread; });
      var b = $("unread"); b.hidden = !n; b.textContent = n > 99 ? "99+" : n;
    });
  }
  function loadNet() { return api("GET", "/network").then(function (n) { S.net = n; paintReach(); }); }
  function paintReach() {
    var p = $("reach"), n = S.net;
    if (!n) { p.textContent = ""; return; }
    var c = n.connections;
    p.className = "pill " + (c > 0 ? "good" : "mid");
    p.textContent = c > 0 ? c + " peer" + (c === 1 ? "" : "s") : "no peers";
  }

  /* ---------------------------------------------------------------- live events (Server-Sent Events over fetch, so the token goes in a header) */
  function startEvents() {
    if (S.es) return; S.es = true;
    (function open() {
      fetch("/api/events", { headers: { "X-GC-Token": TOKEN }, cache: "no-store" }).then(function (r) {
        var rd = r.body.getReader(), dec = new TextDecoder(), buf = "";
        function pump() {
          return rd.read().then(function (x) {
            if (x.done) throw new Error("closed");
            buf += dec.decode(x.value, { stream: true });
            var parts = buf.split("\n\n"); buf = parts.pop();
            parts.forEach(function (p) {
              if (p.indexOf("data: ") === 0) { try { onEvent(JSON.parse(p.slice(6))); } catch (e) { /* ignore bad event */ } }
            });
            return pump();
          });
        }
        return pump();
      }).catch(function () { setTimeout(open, 2000); });
    })();
  }
  function later(key, fn, ms) { clearTimeout(timers[key]); timers[key] = setTimeout(fn, ms); }
  function onEvent(ev) {
    var r = route().name;
    if (ev.type === "dm") {
      loadConvs();
      if (r === "chat" && S.thread === ev.data.peer) later("thread", function () { showThread(S.thread, true); }, 120);
      else if (r === "chats") later("v", render, 150);
    } else if (ev.type === "group") {
      var rm = ev.data && ev.data.room;
      if (r === "group" && (!rm || rm === "global")) later("v", function () { showGroup(true); }, 120);
      else if (r === "room" && S.room && S.room === rm) later("v", function () { showRoom(S.room, true); }, 120);
      else if (r === "groups") later("v", render, 400);
    } else if (ev.type === "presence" || ev.type === "peer_connected" || ev.type === "peer_disconnected") {
      loadNet(); if (r === "peers" || r === "home") later("v", render, 600);
    } else if (ev.type === "network") {
      loadNet(); if (r === "network") later("v", render, 400);
    } else if (ev.type === "state") {
      loadState();
    }
  }

  /* ---------------------------------------------------------------- routing */
  function route() {
    var h = location.hash.replace(/^#\/?/, "") || "home", p = h.split("/");
    return { name: p[0], arg: p[1] };
  }
  function go(h) { location.hash = "#/" + h; }
  window.addEventListener("hashchange", render);
  $("back").addEventListener("click", function () { history.length > 1 ? history.back() : go("home"); });

  var TITLES = { home: "G-rise", peers: "Online users", chats: "Chats", group: "Global group", groups: "Groups", newgroup: "Create group", room: "Group", more: "More", profile: "My profile",
    username: "Change username", network: "Network status", settings: "Settings", security: "Security & identity", free: "Free for everyone", chat: "Chat" };
  var NAVS = { home: 1, peers: 1, chats: 1, groups: 1, more: 1 };

  function render() {
    var r = route();
    if (!S.st) return;
    var has = S.st.has_identity;
    if (!has || r.name === "name" || r.name === "create") {
      if (has && r.name === "create") return go("home");
      return welcome(r.name);
    }
    $("top").hidden = false; paintReach();
    $("nav").hidden = r.name === "chat" || !NAVS[r.name];
    var tabs = document.querySelectorAll("#nav a");
    for (var i = 0; i < tabs.length; i++) tabs[i].classList.toggle("on", tabs[i].getAttribute("data-r") === r.name);
    $("title").textContent = TITLES[r.name] || "G-rise";
    $("back").hidden = !!NAVS[r.name];
    S.thread = r.name === "chat" ? r.arg : null; S.room = r.name === "room" ? r.arg : null;
    var f = { home: showHome, peers: showPeers, chats: showChats, group: function () { showGroup(); }, groups: showGroups, newgroup: showNewGroup, room: function () { showRoom(r.arg); }, more: showMore, profile: showProfile,
      username: showUsername, network: showNetwork, settings: showSettings, security: showSecurity, free: showFree,
      chat: function () { showThread(r.arg); } }[r.name];
    if (!f) { go("home"); return; }
    f();
  }

  /* ---------------------------------------------------------------- 1-3: welcome, identity creation, username */
  function steps(n) { return '<div class="steps"><b class="' + (n >= 1 ? "on" : "") + '"></b><b class="' + (n >= 2 ? "on" : "") + '"></b><b class="' + (n >= 3 ? "on" : "") + '"></b></div>'; }
  function welcome(name) {
    $("top").hidden = true; $("nav").hidden = true;
    if (name === "create") return createIdentity();
    if (name === "name") return nameStep();
    setView('<div class="hero"><div class="logo">&#127760;</div><h2>G-rise</h2>' +
      '<p>Private messaging with no central server. Every phone running this app is a node in the network.</p></div>' + steps(1) +
      '<div class="card"><ul class="bullets"><li>No phone number, email or social account</li><li>An anonymous cryptographic identity is created on this phone</li>' +
      '<li>Messages are end-to-end encrypted and go directly between phones when possible</li><li>No one can read, store or censor them centrally</li></ul>' +
      '<button class="btn block" id="go">Create my anonymous identity</button></div>' +
      '<p class="muted small center">Decentralised does not mean always reachable: Network status shows what works from your connection.</p>');
    $("go").onclick = function () { go("create"); };
  }
  function createIdentity() {
    setView('<div class="hero"><div class="logo">&#128273;</div><h2>Your anonymous identity</h2><p>Keys are generated on this phone and never leave it.</p></div>' + steps(2) +
      '<div class="card"><p>Creating:</p><ul class="bullets"><li>Ed25519 signing key (proves messages are yours)</li><li>X25519 encryption key (for end-to-end encryption)</li>' +
      '<li>A permanent peer ID derived from your public key</li></ul><button class="btn block" id="mk">Generate keys</button><div class="err" id="e"></div></div>');
    $("mk").onclick = function () {
      var b = $("mk"); b.disabled = true; b.textContent = "Generating...";
      api("POST", "/identity/create", {}).then(function (s) { S.st = s; return loadNet().catch(function () {}); })
        .then(function () { startEvents(); go("name"); })
        .catch(function (e) { b.disabled = false; b.textContent = "Generate keys"; $("e").textContent = e.message; });
    };
  }
  function nameStep() {
    if (!S.st.has_identity) return go("welcome");
    setView('<div class="hero"><div class="logo">&#128100;</div><h2>Choose a username</h2><p>Anyone may use any name, so your peer ID suffix is always shown next to it.</p></div>' + steps(3) +
      '<div class="card"><div class="row"><div class="av" id="pv"></div><div class="grow"><div class="small muted">Your peer ID</div><div class="mono" id="pid"></div></div></div>' +
      '<label class="lbl" for="un">Username (3-24 letters, digits, _ . -)</label><input class="field" id="un" maxlength="24" autocomplete="off" autocapitalize="none" spellcheck="false">' +
      '<div class="err" id="e"></div><button class="btn block" id="ok">Start chatting</button></div>');
    $("pid").textContent = S.st.peer_id; var av = avatar(S.st.username, S.st.peer_id); $("pv").replaceWith(av);
    $("un").value = S.st.username;
    $("ok").onclick = function () {
      api("POST", "/username", { username: $("un").value }).then(function (s) { S.st = s; return loadNet(); })
        .then(function () { go("home"); toast("Welcome, " + S.st.username); })
        .catch(function (e) { $("e").textContent = e.message; });
    };
  }

  /* ---------------------------------------------------------------- 4: dashboard */
  function showHome() {
    Promise.all([loadPeers(), loadConvs(), loadNet()]).then(function () {
      var n = S.net, online = S.peers.filter(function (p) { return p.state === "online"; }).length;
      var d = el("div");
      var me = el("div", "card");
      me.innerHTML = '<div class="row"><div id="av"></div><div class="grow"><h2></h2><div class="mono small muted"></div></div></div>';
      me.querySelector("#av").replaceWith(avatar(S.st.username, S.st.peer_id));
      me.querySelector("h2").textContent = S.st.handle;
      me.querySelector(".mono").textContent = S.st.peer_id.slice(0, 14) + "..." + S.st.peer_id.slice(-6);
      d.appendChild(me);
      if (!n.connections) {
        d.appendChild(el("div", "note warn", "<b>Not connected to any peer yet.</b> Join the network by adding the address of a peer a friend gave you " +
          "(for example <span class='mono'>gcp2p://...@ip:port</span>) under <a href='#/network'>Network status</a>. Phones on the same Wi-Fi find each other automatically."));
      }
      var t = el("div", "tiles");
      t.innerHTML = '<a class="tile" href="#/peers"><b>' + online + '</b><span>online users</span></a>' +
        '<a class="tile" href="#/network"><b>' + n.connections + '</b><span>connected peers (' + n.direct + ' direct, ' + n.relayed + ' relayed)</span></a>' +
        '<a class="tile" href="#/groups"><b>&#9733;</b><span>Groups</span></a>' +
        '<a class="tile" href="#/chats"><b>' + S.convs.length + '</b><span>private chats</span></a>';
      d.appendChild(t);
      if (S.convs.length) {
        var c = el("div", "card"); c.innerHTML = "<h2>Recent chats</h2>"; d.appendChild(c);
        S.convs.slice(0, 3).forEach(function (cv) { d.appendChild(convItem(cv)); });
      }
      setView(d);
    }).catch(showErr);
  }

  /* ---------------------------------------------------------------- 5: online peers */
  function showPeers() {
    var d = el("div");
    d.innerHTML = '<div class="row wrap"><button class="btn ghost grow" id="rf">&#8635; Refresh discovery</button></div><div class="note">Only peers reachable through the network appear here. ' +
      'Presence records are signed and expire, so someone who closed the app disappears after a few minutes. Nobody here is simulated.</div><div id="pl"></div>';
    setView(d);
    function paint() {
      var box = $("pl"); if (!box) return; box.innerHTML = "";
      var list = S.peers.filter(function (p) { return p.peer_id !== S.st.peer_id; });
      if (!list.length) { box.appendChild(el("div", "empty", "<big>&#128752;</big>No other peers found yet.<br>Connect to a peer in <a href='#/network'>Network status</a>, or open the app on a phone on the same Wi-Fi.")); return; }
      list.forEach(function (p) {
        var a = el("a", "item"); a.href = "#/chat/" + p.peer_id;
        a.appendChild(avatar(p.username, p.peer_id, p.state));
        var m = el("div", "grow"); var nm = el("div", "nm"); nm.textContent = p.handle; m.appendChild(nm);
        var sb = el("div", "sub"); sb.textContent = (p.state === "online" ? (p.via === "relay" ? "via relay" : p.via === "direct" ? "direct connection" : "reachable") : "last seen " + ago(p.last_seen) + " ago"); m.appendChild(sb);
        a.appendChild(m); a.appendChild(el("span", "state " + p.state, STATE_TXT[p.state]));
        box.appendChild(a);
      });
    }
    loadPeers().then(paint).catch(showErr);
    $("rf").onclick = function () {
      var b = $("rf"); b.disabled = true; b.textContent = "Searching...";
      api("POST", "/peers/refresh", {}).then(function (r) { S.peers = r.peers; paint(); toast("Discovery refreshed"); })
        .catch(function (e) { toast(e.message); }).then(function () { b.disabled = false; b.innerHTML = "&#8635; Refresh discovery"; });
    };
  }

  /* ---------------------------------------------------------------- chats list */
  function convItem(c) {
    var a = el("a", "item"); a.href = "#/chat/" + c.peer;
    a.appendChild(avatar(c.username, c.peer, c.state));
    var m = el("div", "grow"), nm = el("div", "nm"), sb = el("div", "sub");
    nm.textContent = c.handle; sb.textContent = (c.dir === "out" ? "You: " : "") + (c.last_kind === "media" ? mediaLabel(c.last) : c.last); m.appendChild(nm); m.appendChild(sb); a.appendChild(m);
    var r = el("div"); r.appendChild(el("div", "small muted", ago(c.ts)));
    if (c.unread) { var b = el("span", "badge"); b.textContent = c.unread; r.appendChild(b); }
    a.appendChild(r); return a;
  }
  function showChats() {
    loadConvs().then(function () {
      var d = el("div");
      if (!S.convs.length) d.appendChild(el("div", "empty", "<big>&#9993;</big>No private chats yet.<br>Pick someone in <a href='#/peers'>Online users</a> to start one."));
      S.convs.forEach(function (c) { d.appendChild(convItem(c)); });
      setView(d);
    }).catch(showErr);
  }

  /* ---------------------------------------------------------------- 6: private chat */
  function shell(key, ph, max, send, attach) {
    if (view.getAttribute("data-k") !== key || !$("th")) {
      view.className = "chatview"; view.setAttribute("data-k", key);
      view.innerHTML = '<div class="thread" id="th"></div><div class="composer">' +
        (attach ? '<button class="btn ghost clip" id="at" aria-label="Send a photo or video">&#128206;</button><input type="file" id="fi" accept="image/*,video/*" hidden>' : "") +
        '<textarea class="field" id="tx" rows="1" placeholder="' + ph +
        '" maxlength="' + max + '"></textarea><button class="btn" id="sd" aria-label="Send">&#10148;</button></div>';
      wire($("tx"), $("sd"), send);
      if (attach) {
        $("at").onclick = function () { $("fi").click(); };
        $("fi").onchange = function () { var f = this.files && this.files[0]; this.value = ""; if (f) attach(f); };
      }
      return { th: $("th"), fresh: true };
    }
    return { th: $("th"), fresh: false };
  }
  var TICK = { queued: "&#9719; waiting", sent: "&#10003; stored for delivery", delivered: "&#10003;&#10003; delivered", failed: "&#33; failed" };
  function showThread(peer, keep) {
    api("GET", "/dm/" + peer).then(function (t) {
      if (S.thread !== peer) return;
      $("title").textContent = t.handle;
      var rp = $("reach"); rp.className = "pill " + (t.state === "online" ? "good" : t.state === "unreachable" ? "low" : "mid"); rp.textContent = STATE_TXT[t.state];
      var sh = shell("dm:" + peer, "Message", 4000, function (txt) {
        return api("POST", "/dm/send", { to: peer, text: txt }).then(function () { showThread(peer, true); loadConvs(); });
      }, function (file) { pickMedia(peer, file); });
      var th = sh.th, atBottom = sh.fresh || th.scrollHeight - th.scrollTop - th.clientHeight < 90, keepTop = th.scrollTop;
      th.innerHTML = "";
      if (t.state !== "online") th.appendChild(el("div", "note", "This person is " + STATE_TXT[t.state].toLowerCase() + ". Messages are encrypted and kept on your phone " +
        "(and, if possible, on helper peers) until they come online. Delivery is not guaranteed if nobody can hold them."));
      var last = "";
      t.messages.forEach(function (m) {
        var dl = dayLabel(m.ts); if (dl !== last) { th.appendChild(el("div", "day", esc(dl))); last = dl; }
        var b = el("div", "msg" + (m.dir === "out" ? " me" : "")); var body = el("div");
        if (m.media) body = mediaBody(m, peer); else body.textContent = m.body;
        b.appendChild(body);
        var meta = el("div", "meta"); meta.innerHTML = esc(clock(m.ts)) + (m.dir === "out" ? " &middot; " + (TICK[m.status] || esc(m.status)) : "");
        if (m.dir === "out" && (m.status === "failed" || m.status === "queued")) {
          var rb = el("button", "retry", "retry"); rb.onclick = function () { api("POST", "/dm/retry", { id: m.id }).then(function () { toast("Retrying"); showThread(peer, true); }).catch(function (e) { toast(e.message); }); };
          meta.appendChild(rb);
        }
        b.appendChild(meta);
        if (m.note) { var nt = el("div", "meta"); nt.textContent = m.note; b.appendChild(nt); }
        th.appendChild(b);
      });
      th.scrollTop = atBottom ? th.scrollHeight : keepTop;
      api("POST", "/dm/" + peer + "/read", {}).then(loadConvs);
    }).catch(function (e) { showErr(e); });
  }
  /* ---- photos and videos (optionally view once) ---- */
  function mediaLabel(raw) {
    try { var o = JSON.parse(raw); return (o.k === "image" ? "\uD83D\uDCF7 Photo" : "\uD83C\uDFAC Video") + (o.o ? " (view once)" : ""); } catch (e) { return "Media"; }
  }
  function mb(n) { return (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + " MB"; }
  function fetchBlob(id) {
    return fetch("/api/media/" + id, { headers: { "X-GC-Token": TOKEN }, cache: "no-store" }).then(function (r) {
      if (!r.ok) return r.json().catch(function () { return {}; }).then(function (j) { throw new Error(j.error || "Cannot open"); });
      return r.blob();
    });
  }
  function overlay() {
    var o = el("div", "ov"); o.setAttribute("role", "dialog"); document.getElementById("app").appendChild(o);
    o.close = function () { var m = o.querySelector("img,video"); if (m && m.src) URL.revokeObjectURL(m.src); if (m && m.pause) m.pause(); o.remove(); };
    return o;
  }
  function viewMedia(m, peer) {
    fetchBlob(m.id).then(function (blob) {
      var o = overlay(), url = URL.createObjectURL(blob), x = el("button", "icon xbtn", "&#10005;"); x.setAttribute("aria-label", "Close");
      var mm = el(m.kind === "image" ? "img" : "video", "bigmedia"); mm.src = url;
      if (m.kind === "video") { mm.controls = true; mm.autoplay = true; mm.playsInline = true; }
      x.onclick = function () { o.close(); showThread(peer, true); };
      o.appendChild(x); o.appendChild(mm);
      if (m.caption) o.appendChild(el("div", "cap", esc(m.caption)));
      if (m.once && m.dir === "in") o.appendChild(el("div", "once", "View once &mdash; it is deleted when you close this"));
      showThread(peer, true);
    }).catch(function (e) { toast(e.message); showThread(peer, true); });
  }
  function mediaBody(m, peer) {
    var d = m.media, box = el("div", "media"), what = d.kind === "image" ? "photo" : "video", icon = d.kind === "image" ? "&#128247;" : "&#127916;";
    function btn(label, fn) { var b = el("button", "btn small", label); b.onclick = fn; box.appendChild(b); return b; }
    if (d.caption) { var c = el("div", "mcap"); c.textContent = d.caption; }
    if (d.dir === "out") {
      if (d.once) box.appendChild(el("div", "mlbl", "&#128293; " + what + " &middot; view once &middot; " + (d.viewed ? "Opened" : d.state === "delivered" ? "Delivered, not opened" : "Sending&hellip;")));
      else {
        var t = el("div", "mlbl", icon + " " + what + " &middot; " + mb(d.size)); box.appendChild(t);
        btn("View", function () { viewMedia(Object.assign({ dir: "out" }, d), peer); });
      }
    } else if (d.state === "opened" || (d.once && d.viewed)) {
      box.appendChild(el("div", "mlbl gone", "&#128293; Opened &middot; this " + what + " was view once and is gone"));
    } else if (d.state === "expired") {
      box.appendChild(el("div", "mlbl gone", icon + " Not downloaded in time &mdash; ask them to send it again"));
    } else if (d.state === "ready") {
      box.appendChild(el("div", "mlbl", (d.once ? "&#128293; " : icon + " ") + what + (d.once ? " &middot; view once" : " &middot; " + mb(d.size))));
      btn(d.once ? "Tap to view once" : "View", function () { viewMedia(Object.assign({ dir: "in" }, d), peer); });
    } else if (d.state === "downloading") {
      box.appendChild(el("div", "mlbl", icon + " Downloading " + what + "&hellip;"));
    } else {
      box.appendChild(el("div", "mlbl", icon + " " + what + (d.once ? " &middot; view once" : "") + " &middot; " + mb(d.size)));
      btn("Download", function (ev) {
        ev.target.disabled = true; ev.target.textContent = "Downloading\u2026";
        api("POST", "/media/" + d.id + "/download", {}).then(function () { showThread(peer, true); }).catch(function (e) { toast(e.message); showThread(peer, true); });
      });
      if (d.note) { var n = el("div", "mnote"); n.textContent = d.note; box.appendChild(n); }
    }
    if (d.caption) box.appendChild(c);
    return box;
  }
  function downscale(file) {
    return new Promise(function (resolve) {
      if (file.type === "image/gif" || file.type === "image/webp" && file.size < 1500000 || file.size < 700000) return resolve(file);
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(url);
        var k = Math.min(1, 1600 / Math.max(img.width, img.height)), cv = document.createElement("canvas");
        cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
        cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
        cv.toBlob(function (b) { resolve(b && b.size < file.size ? b : file); }, "image/jpeg", 0.82);
      };
      img.onerror = function () { URL.revokeObjectURL(url); resolve(file); };
      img.src = url;
    });
  }
  function pickMedia(peer, file) {
    var isImg = /^image\//.test(file.type), isVid = /^video\//.test(file.type);
    if (!isImg && !isVid) return toast("Choose a photo or a video");
    if (isVid && file.size > 25 * 1048576) return toast("Videos can be at most 25 MB. Trim it or record a shorter one.");
    (isImg ? downscale(file) : Promise.resolve(file)).then(function (blob) {
      if (isImg && blob.size > 6 * 1048576) return toast("This photo is too large (max 6 MB).");
      var o = overlay(), url = URL.createObjectURL(blob);
      var pv = el(isImg ? "img" : "video", "bigmedia prev"); pv.src = url; if (!isImg) { pv.controls = true; pv.muted = true; pv.playsInline = true; }
      var bar = el("div", "sheet");
      bar.innerHTML = '<input class="field" id="mcap" maxlength="200" placeholder="Add a caption (optional)">' +
        '<label class="sw"><span class="t">View once<small>It is deleted from both phones after it is opened</small></span><input type="checkbox" id="monce"></label>' +
        '<div class="row"><button class="btn ghost grow" id="mno">Cancel</button><button class="btn grow" id="myes">Send ' + (isImg ? "photo" : "video") + ' (' + mb(blob.size) + ')</button></div>';
      o.appendChild(pv); o.appendChild(bar);
      $("mno").onclick = function () { o.close(); };
      $("myes").onclick = function () {
        var b = this; b.disabled = true; b.textContent = "Sending\u2026";
        var q = "?to=" + encodeURIComponent(peer) + "&mime=" + encodeURIComponent(blob.type || file.type) + "&once=" + ($("monce").checked ? "1" : "0") +
          "&caption=" + encodeURIComponent($("mcap").value);
        fetch("/api/media/send" + q, { method: "POST", headers: { "X-GC-Token": TOKEN, "Content-Type": "application/octet-stream" }, body: blob }).then(function (r) {
          return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) throw new Error(j.error || "Could not send"); });
        }).then(function () { o.close(); showThread(peer, true); loadConvs(); })
          .catch(function (e) { b.disabled = false; b.textContent = "Try again"; toast(e.message); });
      };
    });
  }
  function wire(tx, sd, send) {
    function fire() {
      var v = tx.value.trim(); if (!v) return; sd.disabled = true;
      send(v).then(function () { tx.value = ""; tx.style.height = ""; }).catch(function (e) { toast(e.message); }).then(function () { sd.disabled = false; tx.focus(); });
    }
    sd.onclick = fire;
    tx.addEventListener("input", function () { tx.style.height = "auto"; tx.style.height = Math.min(120, tx.scrollHeight) + "px"; });
    tx.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); fire(); } });
  }

  /* ---------------------------------------------------------------- 7: global group */
  function showGroup(keep) {
    api("GET", "/group").then(function (r) {
      if (route().name !== "group") return;
      var sh = shell("group", "Message everyone", 1000, function (txt) {
        return api("POST", "/group/send", { text: txt }).then(function () { showGroup(true); });
      });
      var th = sh.th, atBottom = sh.fresh || th.scrollHeight - th.scrollTop - th.clientHeight < 90, keepTop = th.scrollTop;
      th.innerHTML = "";
      th.appendChild(el("div", "note", "Public room. Messages spread peer to peer, are signed by their sender and are visible to every participant. " +
        "They are not private. You only see what reached the peers you are connected to."));
      var last = "";
      r.messages.forEach(function (m) {
        var dl = dayLabel(m.ts); if (dl !== last) { th.appendChild(el("div", "day", esc(dl))); last = dl; }
        var b = el("div", "msg" + (m.mine ? " me" : ""));
        if (!m.mine) { var w = el("div", "who"); w.textContent = m.handle; b.appendChild(w); }
        var body = el("div"); body.textContent = m.body; b.appendChild(body);
        b.appendChild(el("div", "meta", esc(clock(m.ts)))); th.appendChild(b);
      });
      th.scrollTop = atBottom ? th.scrollHeight : keepTop;
    }).catch(showErr);
  }

  /* ---------------------------------------------------------------- groups: global room, my groups, discover, create, join by code */
  function ageTxt(ts) { return ts ? "active " + ago(ts) + (ago(ts) === "now" ? "" : " ago") : "no messages seen"; }
  function showGroups() {
    api("GET", "/rooms").then(function (r) {
      var d = el("div"), mine = r.rooms.filter(function (x) { return x.joined; }), disc = r.rooms.filter(function (x) { return !x.joined && x.kind === "public" && !x.closed; });
      var top = el("div", "row wrap"); top.appendChild(el("a", "btn grow", "+ Create group")); top.firstChild.href = "#/newgroup";
      var rf = el("button", "btn ghost", "&#8635;"); rf.setAttribute("aria-label", "Refresh groups");
      rf.onclick = function () { rf.disabled = true; api("POST", "/peers/refresh", {}).then(function () { toast("Groups refreshed"); showGroups(); }).catch(function (e) { toast(e.message); rf.disabled = false; }); };
      top.appendChild(rf); d.appendChild(top); d.appendChild(el("div", "gap"));
      function item(href, name, key, sub, badge, btn) {
        var a = el("a", "item"); a.href = href; a.appendChild(avatar(name, key));
        var m = el("div", "grow"), nm = el("div", "nm"), sb = el("div", "sub"); nm.textContent = (badge ? badge + " " : "") + name; sb.textContent = sub; m.appendChild(nm); m.appendChild(sb); a.appendChild(m);
        if (btn) a.appendChild(btn); return a;
      }
      d.appendChild(item("#/group", "Global group", "global", "Public room for everyone", "\u2605"));
      if (mine.length) d.appendChild(el("h3", "sec", "My groups"));
      mine.forEach(function (g) { d.appendChild(item("#/room/" + g.gid, g.name, g.gid, (g.kind === "private" ? "Private, encrypted" : "Public") + " - " + (g.closed ? "closed by owner" : ageTxt(g.last_ts)), g.kind === "private" ? "\u{1F512}" : "")); });
      d.appendChild(el("h3", "sec", "Discover public groups"));
      if (!disc.length) d.appendChild(el("div", "empty", "No public groups found yet.<br>Groups spread between connected peers. Tap refresh, or create the first one."));
      disc.forEach(function (g) {
        var jb = el("button", "btn small", "Join");
        jb.onclick = function (ev) { ev.preventDefault(); ev.stopPropagation(); jb.disabled = true; api("POST", "/rooms/join", { gid: g.gid }).then(function () { go("room/" + g.gid); }).catch(function (e) { toast(e.message); jb.disabled = false; }); };
        d.appendChild(item("#/room/" + g.gid, g.name, g.gid, (g.desc ? g.desc + " - " : "") + "by " + g.owner_handle + " - " + ageTxt(g.last_ts), "", jb));
      });
      var ic = el("div", "card"); ic.innerHTML = "<h2>Join with an invite code</h2><p>For private groups. Paste the code a member gave you.</p>" +
        '<input class="field" id="ic" placeholder="gcg1:..." autocomplete="off" autocapitalize="none" spellcheck="false"><div class="err" id="ie"></div><button class="btn block" id="ib">Join private group</button>';
      d.appendChild(ic); setView(d);
      $("ib").onclick = function () {
        var v = $("ic").value.trim(); if (!v) return;
        api("POST", "/rooms/join", { invite: v }).then(function (g) { go("room/" + g.gid); }).catch(function (e) { $("ie").textContent = e.message; });
      };
    }).catch(showErr);
  }
  function showNewGroup() {
    setView('<div class="card"><h2>Create a group</h2><label class="lbl" for="gn">Group name (3-40 characters)</label><input class="field" id="gn" maxlength="40" autocomplete="off">' +
      '<label class="lbl" for="gd">Description (optional)</label><input class="field" id="gd" maxlength="120" autocomplete="off">' +
      '<label class="lbl">Who can join?</label>' +
      '<label class="choice"><input type="radio" name="gk" value="public" checked><span><b>Public</b><small>Appears under Discover. Anyone can join with one tap. Messages are signed but not encrypted.</small></span></label>' +
      '<label class="choice"><input type="radio" name="gk" value="private"><span><b>Private</b><small>Hidden. People join with an invite code you share. Messages are encrypted.</small></span></label>' +
      '<div class="err" id="e"></div><button class="btn block" id="mk">Create group</button></div>');
    $("mk").onclick = function () {
      var b = $("mk"); b.disabled = true;
      api("POST", "/rooms/create", { name: $("gn").value, desc: $("gd").value, kind: document.querySelector("input[name=gk]:checked").value })
        .then(function (g) { toast("Group created"); go("room/" + g.gid); })
        .catch(function (e) { $("e").textContent = e.message; b.disabled = false; });
    };
  }
  function showRoom(gid, keep) {
    api("GET", "/rooms/" + gid).then(function (g) {
      if (S.room !== gid) return;
      $("title").textContent = g.name;
      var rp = $("reach"); rp.className = "pill " + (g.kind === "private" ? "good" : "mid"); rp.textContent = g.kind === "private" ? "Private" : "Public";
      if (!g.joined) {
        var d = el("div", "card"); d.innerHTML = "<h2></h2><p class='dsc'></p><p class='small muted own'></p>";
        d.querySelector("h2").textContent = g.name; d.querySelector(".dsc").textContent = g.desc || "No description."; d.querySelector(".own").textContent = "Created by " + g.owner_handle + ". Messages in public groups are not encrypted.";
        var jb = el("button", "btn block", "Join group"); jb.onclick = function () { api("POST", "/rooms/join", { gid: gid }).then(function () { showRoom(gid); }).catch(function (e) { toast(e.message); }); };
        d.appendChild(jb); return setView(d);
      }
      var sh = shell("room:" + gid, "Message the group", 1000, function (txt) {
        return api("POST", "/rooms/" + gid + "/send", { text: txt }).then(function () { showRoom(gid, true); });
      });
      var th = sh.th, atBottom = sh.fresh || th.scrollHeight - th.scrollTop - th.clientHeight < 90, keepTop = th.scrollTop;
      th.innerHTML = "";
      var info = el("div", "note");
      if (g.closed) info.className = "note warn";
      var t = el("div"); t.innerHTML = g.closed ? "<b>The owner closed this group.</b> You can read it but not send." :
        (g.kind === "private" ? "<b>Private group.</b> Messages are encrypted; only people with the invite code can read them. Anyone with the code can join, so share it carefully." :
          "<b>Public group</b> by <span class='who2'></span>. Anyone can find and join it, and messages are <b>not encrypted</b>.");
      var w2 = t.querySelector(".who2"); if (w2) w2.textContent = g.owner_handle;
      info.appendChild(t);
      if (g.invite) {
        var code = el("div", "mono invite"); code.textContent = g.invite; info.appendChild(code);
        var cb = el("button", "btn ghost block", "Copy invite code"); cb.onclick = function () { copy(g.invite, "Invite code"); }; info.appendChild(cb);
      }
      var row = el("div", "row wrap gapt");
      var lb = el("button", "btn ghost grow", "Leave group"); lb.onclick = function () {
        if (!confirm("Leave this group? Its messages are deleted from this phone" + (g.kind === "private" ? " and you will need the invite code to return." : "."))) return;
        api("POST", "/rooms/leave", { gid: gid }).then(function () { go("groups"); }).catch(function (e) { toast(e.message); });
      }; row.appendChild(lb);
      if (g.mine && g.kind === "public" && !g.closed) {
        var xb = el("button", "btn danger grow", "Close group"); xb.onclick = function () {
          if (!confirm("Close this group for everyone? Nobody will be able to join or send.")) return;
          api("POST", "/rooms/close", { gid: gid }).then(function () { toast("Group closed"); showRoom(gid, true); }).catch(function (e) { toast(e.message); });
        }; row.appendChild(xb);
      }
      info.appendChild(row); th.appendChild(info);
      var last = "";
      g.messages.forEach(function (m) {
        var dl = dayLabel(m.ts); if (dl !== last) { th.appendChild(el("div", "day", esc(dl))); last = dl; }
        var b = el("div", "msg" + (m.mine ? " me" : ""));
        if (!m.mine) { var w = el("div", "who"); w.textContent = m.handle; b.appendChild(w); }
        var body = el("div"); body.textContent = m.body; b.appendChild(body);
        b.appendChild(el("div", "meta", esc(clock(m.ts)))); th.appendChild(b);
      });
      th.scrollTop = atBottom ? th.scrollHeight : keepTop;
    }).catch(showErr);
  }

  /* ---------------------------------------------------------------- more menu, 8: profile, 9: username */
  function showMore() {
    setView('<div class="card menu"><a href="#/profile"><i>&#128100;</i><span>My profile</span><em>&#8250;</em></a><a href="#/username"><i>&#9998;</i><span>Change username</span><em>&#8250;</em></a>' +
      '<a href="#/network"><i>&#128246;</i><span>Network status</span><em>&#8250;</em></a><a href="#/settings"><i>&#9881;</i><span>Settings</span><em>&#8250;</em></a>' +
      '<a href="#/security"><i>&#128274;</i><span>Security &amp; identity</span><em>&#8250;</em></a>' +
      '<a href="#/free"><i>&#10003;</i><span>Free for everyone</span><em>&#8250;</em></a></div>' +
      '<p class="small muted">G-rise 1.0 &middot; all features free &middot; no ads.</p>');
    if (window.GCHost) api("GET", "/node").then(function (ni) {
      if (!ni.url) return;
      var nc = el("div", "card");
      nc.innerHTML = "<h2>Node dashboard</h2><p>This phone is running as a node. Open the dashboard in your phone's browser to see users online and the map.</p>" +
        '<dl class="kv"><dt>Address</dt><dd class="mono" id="nu"></dd><dt>Username</dt><dd id="nn"></dd><dt>Password</dt><dd class="mono" id="np">&bull;&bull;&bull;&bull;&bull;&bull;</dd><dt>Node port</dt><dd id="nt"></dd></dl>';
      nc.querySelector("#nu").textContent = ni.url; nc.querySelector("#nn").textContent = ni.user; nc.querySelector("#nt").textContent = ni.port;
      var open = el("button", "btn block", "Open dashboard"); open.onclick = function () { window.GCHost.openUrl(ni.url); };
      var show = el("button", "btn ghost block", "Show / copy password");
      show.onclick = function () { nc.querySelector("#np").textContent = ni.password; copy(ni.password, "Password"); };
      nc.appendChild(open); nc.appendChild(el("div", "gap")); nc.appendChild(show); view.insertBefore(nc, view.children[1] || null);
    }).catch(function () {});
    if (window.GCHost) {
      var c = el("div", "card");
      c.innerHTML = "<h2>This phone</h2><p>Android may stop background apps to save battery, which disconnects you. Set G-rise to <b>Unrestricted</b> or <b>Not optimised</b> so messages keep arriving.</p>";
      var b1 = el("button", "btn ghost block", "Battery settings"); b1.onclick = function () { window.GCHost.batterySettings(); };
      var b2 = el("button", "btn danger block", "Quit and disconnect"); b2.onclick = function () { if (confirm("Disconnect from the network and stop receiving messages until you open the app again?")) window.GCHost.quit(); };
      c.appendChild(b1); c.appendChild(el("div", "gap")); c.appendChild(b2); view.appendChild(c);
    }
  }

  /* ----------------------------------------------------------- free community */
  function showFree() {
    var d = el("div");
    d.appendChild(el("div", "card", "<h2>G-rise is free for everyone</h2><p>No Premium plan, no Business plan, no subscriptions, no trial timers, no paid feature gates, and no advertisements.</p><p>Private messaging and the peer-to-peer network remain independent of payments and advertising services.</p>"));
    d.appendChild(el("div", "card", "<h2>Included without charge</h2><ul class='bullets'><li>Private messaging and end-to-end encryption</li><li>Public and private groups</li><li>Profile and username features</li><li>Group creation and available moderation tools</li><li>Business and community profile capabilities as they are implemented</li><li>Community announcements and insights as they are implemented</li><li>Available themes, customization and network features</li><li>Peer-to-peer connectivity and offline relay capabilities supported by the network</li></ul>"));
    d.appendChild(el("div", "note", "<b>Our promise:</b> No feature will require a Premium or Business payment. Some capabilities listed as future or planned features may not yet exist in this build; they will remain free when implemented."));
    setView(d);
  }

  function showProfile() {
    api("GET", "/identity").then(function (i) {
      S.ident = i;
      var d = el("div"), c = el("div", "card");
      c.innerHTML = '<div class="row"><div id="av"></div><div class="grow"><h2></h2><div class="small muted">Anonymous &middot; no phone, no email</div></div></div>' +
        '<dl class="kv"><dt>Username</dt><dd id="a"></dd><dt>Peer ID</dt><dd class="mono" id="b"></dd><dt>Fingerprint</dt><dd class="mono" id="f"></dd></dl>' +
        '<div class="row wrap"><button class="btn ghost grow" id="c1">Copy peer ID</button><a class="btn ghost grow" href="#/username">Change username</a></div>';
      c.querySelector("#av").replaceWith(avatar(i.username, i.peer_id));
      c.querySelector("h2").textContent = i.handle; c.querySelector("#a").textContent = i.username;
      c.querySelector("#b").textContent = i.peer_id; c.querySelector("#f").textContent = i.fingerprint;
      d.appendChild(c);
      var inv = el("div", "card"); inv.innerHTML = "<h2>Invite address</h2>";
      if (i.invites.length) {
        inv.appendChild(el("p", "", "Give this to a friend so their app can connect to yours (it works while you are reachable from the Internet or on the same network)."));
        i.invites.forEach(function (a) { var m = el("div", "mono"); m.textContent = a; inv.appendChild(m); var b = el("button", "btn ghost block", "Copy invite"); b.onclick = function () { copy(a, "Invite"); }; inv.appendChild(b); });
      } else inv.appendChild(el("p", "", "No public address known yet. Phones on mobile data are usually behind the carrier network, so they cannot be dialled directly; they connect out to peers and can be reached through relays."));
      d.appendChild(inv); setView(d);
      $("c1").onclick = function () { copy(i.peer_id, "Peer ID"); };
    }).catch(showErr);
  }
  function showUsername() {
    setView('<div class="card"><h2>Change username</h2><p>Your permanent peer ID stays the same, so your chats and contacts are not affected. Others see the new name after the network updates.</p>' +
      '<label class="lbl" for="un">New username</label><input class="field" id="un" maxlength="24" autocomplete="off" autocapitalize="none" spellcheck="false"><div class="err" id="e"></div>' +
      '<button class="btn block" id="ok">Save</button></div>');
    $("un").value = S.st.username;
    $("ok").onclick = function () {
      api("POST", "/username", { username: $("un").value }).then(function (s) { S.st = s; toast("Username changed"); go("profile"); }).catch(function (e) { $("e").textContent = e.message; });
    };
  }

  /* ---------------------------------------------------------------- 10: network status */
  function showNetwork() {
    Promise.all([loadNet(), api("GET", "/bootstrap")]).then(function (x) {
      var n = S.net, bl = x[1].bootstrap, d = el("div");
      var REACH = { public: "Reachable from the Internet", private: "Behind NAT (not dialable)", unknown: "Not determined yet" };
      var c = el("div", "card");
      c.innerHTML = '<h2>Status</h2><dl class="kv"><dt>Reachability</dt><dd>' + esc(REACH[n.reachability] || n.reachability) + '</dd>' +
        '<dt>Connections</dt><dd>' + n.connections + ' (' + n.direct + ' direct, ' + n.relayed + ' relayed)</dd><dt>Known peers</dt><dd>' + n.known_peers + '</dd>' +
        '<dt>DHT routing table</dt><dd>' + n.routing_table + '</dd><dt>Relays I use</dt><dd>' + n.my_relays.length + '</dd><dt>Acting as relay</dt><dd>' + (n.relay_enabled ? "yes (" + n.relay_clients + " clients)" : "no") + '</dd>' +
        '<dt>Held for others (encrypted)</dt><dd>' + n.mailbox_held + '</dd><dt>Local Wi-Fi discovery</dt><dd>' + (n.lan ? "on" : "off") + '</dd>' +
        '<dt>Listening port</dt><dd>' + (n.listening ? n.port : "off") + '</dd><dt>Blocked peers</dt><dd>' + n.banned + '</dd></dl>';
      d.appendChild(c);
      var a = el("div", "card"); a.innerHTML = "<h2>Join the network</h2><p>Paste a peer address: <span class='mono'>gcp2p://peerid@host:port</span>. It is saved and used for discovery every time the app starts.</p>" +
        '<input class="field" id="ad" placeholder="gcp2p://...@host:port" autocomplete="off" autocapitalize="none" spellcheck="false"><div class="err" id="e"></div>' +
        '<div class="row wrap"><button class="btn grow" id="ab">Save &amp; connect</button><button class="btn ghost grow" id="cb">Connect once</button></div>';
      d.appendChild(a);
      var b = el("div", "card"); b.innerHTML = "<h2>Saved bootstrap peers</h2>";
      if (!bl.length) b.appendChild(el("p", "", "None. Without any, you can still find phones on the same Wi-Fi."));
      bl.forEach(function (x) { var r = el("div", "row"); var m = el("div", "mono grow"); m.textContent = x; r.appendChild(m);
        var rm = el("button", "btn ghost", "Remove"); rm.onclick = function () { api("POST", "/bootstrap/remove", { addr: x }).then(showNetwork); }; r.appendChild(rm); b.appendChild(r); });
      d.appendChild(b);
      d.appendChild(el("div", "note", "<b>How this works.</b> Peers are found by a Kademlia DHT starting from bootstrap peers. Bootstrap and relay peers only help phones find and reach each other; they cannot read messages. " +
        "Two phones that are both behind mobile-carrier NAT need a relay peer that is publicly reachable (for example a PC or VPS running <span class='mono'>python -m gcp2p</span>). Hole punching is attempted but is not guaranteed on every carrier."));
      setView(d);
      function act(save) {
        var v = $("ad").value.trim(); if (!v) return; $("e").textContent = "";
        (save ? api("POST", "/bootstrap/add", { addr: v }) : api("POST", "/connect", { addr: v })).then(function (r) {
          toast(save ? "Saved; connecting" : (r.connected ? "Connected" : "Could not connect")); setTimeout(showNetwork, 900);
        }).catch(function (e) { $("e").textContent = e.message; });
      }
      $("ab").onclick = function () { act(true); }; $("cb").onclick = function () { act(false); };
    }).catch(showErr);
  }

  /* ---------------------------------------------------------------- 11: settings */
  var CITIES = [["Abuja",9.1,7.4],["Lagos",6.5,3.4],["Kano",12.0,8.5],["Kaduna",10.5,7.4],["Ibadan",7.4,3.9],["Port Harcourt",4.8,7.0],["Benin City",6.3,5.6],
    ["Maiduguri",11.8,13.2],["Sokoto",13.1,5.2],["Katsina",13.0,7.6],["Jos",9.9,8.9],["Enugu",6.5,7.5],["Ilorin",8.5,4.5],["Bauchi",10.3,9.8],["Gombe",10.3,11.2],
    ["Yola",9.2,12.5],["Minna",9.6,6.6],["Zaria",11.1,7.7],["Calabar",5.0,8.3],["Owerri",5.5,7.0],["Accra",5.6,-0.2],["Niamey",13.5,2.1],["N'Djamena",12.1,15.0],
    ["Dakar",14.7,-17.5],["Abidjan",5.3,-4.0],["Nairobi",-1.3,36.8],["Addis Ababa",9.0,38.7],["Cairo",30.0,31.2],["Johannesburg",-26.2,28.0],["Casablanca",33.6,-7.6],
    ["Khartoum",15.5,32.6],["Riyadh",24.7,46.7],["Mecca",21.4,39.8],["Dubai",25.2,55.3],["Istanbul",41.0,29.0],["London",51.5,-0.1],["Paris",48.9,2.4],["Berlin",52.5,13.4],
    ["Madrid",40.4,-3.7],["New York",40.7,-74.0],["Toronto",43.7,-79.4],["Houston",29.8,-95.4],["Los Angeles",34.1,-118.2],["Sao Paulo",-23.6,-46.6],["Mumbai",19.1,72.9],
    ["Karachi",24.9,67.0],["Dhaka",23.8,90.4],["Singapore",1.3,103.8],["Beijing",39.9,116.4],["Tokyo",35.7,139.7],["Sydney",-33.9,151.2]];
  function showSettings() {
    api("GET", "/settings").then(function (s) {
      S.settings = s; var d = el("div"), c = el("div", "card");
      var rows = [["notifications", "Message notifications", "Show a notification for new messages."],
        ["lan", "Find peers on this Wi-Fi", "Broadcast signed presence on the local network. Takes effect after restarting the app."],
        ["listen", "Accept incoming connections", "Lets others connect directly to you. Takes effect after restarting the app."],
        ["relay", "Help others as a relay", "Only used when this device is publicly reachable. Relays carry encrypted data they cannot read."],
        ["store_forward", "Hold encrypted messages for others", "Keeps sealed offline messages for a few days so offline friends can fetch them. You cannot read them."]];
      rows.forEach(function (r) {
        var w = el("label", "sw"); w.innerHTML = '<div class="t">' + esc(r[1]) + '<small>' + esc(r[2]) + '</small></div><input type="checkbox">';
        var i = w.querySelector("input"); i.checked = !!s[r[0]];
        i.onchange = function () { var p = {}; p[r[0]] = i.checked; api("POST", "/settings", p).then(function () { toast("Saved"); }).catch(function (e) { toast(e.message); i.checked = !i.checked; }); };
        c.appendChild(w);
      });
      d.appendChild(c);
      var lc = el("div", "card"); lc.innerHTML = "<h2>Show me on the map</h2><p>Optional and <b>off by default</b>. Node operators can show a map of users. If you choose a place, an approximate position " +
        "(rounded to about 11 km) is added to your signed presence and shared with peers. Your real position is never used, and you can stop at any time.</p>" +
        '<label class="lbl" for="city">Nearest city</label><select class="field" id="city"></select>' +
        '<div class="row"><div class="grow"><label class="lbl" for="lat">Latitude</label><input class="field" id="lat" inputmode="decimal"></div>' +
        '<div class="grow"><label class="lbl" for="lon">Longitude</label><input class="field" id="lon" inputmode="decimal"></div></div><div class="err" id="le"></div>' +
        '<div class="row wrap"><button class="btn grow" id="ls">Share this place</button><button class="btn ghost grow" id="lx">Stop sharing</button></div><p class="small" id="lst"></p>';
      d.appendChild(lc);
      var sel = lc.querySelector("#city"); sel.appendChild(new Option("Choose...", ""));
      CITIES.forEach(function (x, i) { sel.appendChild(new Option(x[0], String(i))); });
      sel.onchange = function () { var x = CITIES[+sel.value]; if (x) { lc.querySelector("#lat").value = x[1]; lc.querySelector("#lon").value = x[2]; } };
      function paintLoc(l) { lc.querySelector("#lst").textContent = l.shared ? "Sharing: " + (l.label ? l.label + " " : "") + "(" + l.lat + ", " + l.lon + ")" : "Not sharing any location."; }
      api("GET", "/location").then(paintLoc);
      lc.querySelector("#ls").onclick = function () {
        var lat = parseFloat(lc.querySelector("#lat").value), lon = parseFloat(lc.querySelector("#lon").value), x = CITIES[+sel.value];
        if (isNaN(lat) || isNaN(lon)) { lc.querySelector("#le").textContent = "Choose a city or type latitude and longitude."; return; }
        api("POST", "/location", { lat: lat, lon: lon, label: x ? x[0] : "" }).then(function (l) { lc.querySelector("#le").textContent = ""; paintLoc(l); toast("Location shared (approximate)"); })
          .catch(function (e) { lc.querySelector("#le").textContent = e.message; });
      };
      lc.querySelector("#lx").onclick = function () { api("POST", "/location", { shared: false }).then(function (l) { paintLoc(l); toast("No longer sharing"); }); };
      var dz = el("div", "card"); dz.innerHTML = "<h2>Reset identity</h2><p>Deletes your keys, username and all messages from this phone. This cannot be undone and your peer ID is gone for good.</p>";
      var rb = el("button", "btn danger block", "Delete identity and data"); rb.onclick = function () {
        if (!confirm("Delete your identity and ALL messages from this phone? This cannot be undone.")) return;
        api("POST", "/identity/reset", { confirm: "DELETE" }).then(function () { return loadState(); }).then(function () { go("welcome"); render(); }).catch(function (e) { toast(e.message); });
      }; dz.appendChild(rb); d.appendChild(dz); setView(d);
    }).catch(showErr);
  }

  /* ---------------------------------------------------------------- 12: security & identity */
  function showSecurity() {
    api("GET", "/identity").then(function (i) {
      var d = el("div"), c = el("div", "card");
      c.innerHTML = '<h2>Your identity</h2><dl class="kv"><dt>Peer ID</dt><dd class="mono" id="p"></dd><dt>Fingerprint</dt><dd class="mono" id="f"></dd>' +
        '<dt>Signing</dt><dd>' + esc(i.signing) + '</dd><dt>Key agreement</dt><dd>' + esc(i.key_agreement) + '</dd><dt>Cipher</dt><dd>' + esc(i.cipher) + '</dd></dl>' +
        '<p>' + esc(i.storage) + '</p>';
      c.querySelector("#p").textContent = i.peer_id; c.querySelector("#f").textContent = i.fingerprint; d.appendChild(c);
      var k = el("div", "card"); k.innerHTML = "<h2>Public keys</h2><div class='small muted'>Signing key</div><div class='mono'></div><div class='small muted'>Encryption key</div><div class='mono'></div>";
      var m = k.querySelectorAll(".mono"); m[0].textContent = i.public_key; m[1].textContent = i.encryption_key; d.appendChild(k);
      d.appendChild(el("div", "note", "<b>Verify a contact.</b> Your peer ID is derived from your public key, so nobody can claim it without your private key. To be sure you are talking to the right person, compare fingerprints with them over another channel."));
      d.appendChild(el("div", "note warn", "<b>Honest status.</b> The cryptography uses standard, widely reviewed primitives, but this app as a whole has <b>not</b> had an independent security audit. Do not rely on it where lives or liberty depend on it. " +
        "The global group is public. Metadata (who connects to whom, and when) is visible to peers you connect to and to network observers; an app like this does not hide your IP address."));
      setView(d);
    }).catch(showErr);
  }

  function showErr(e) { setView('<div class="card"><h2>Something went wrong</h2><p></p><button class="btn" id="rt">Try again</button></div>'); view.querySelector("p").textContent = e.message || String(e); $("rt").onclick = render; }

  /* ---------------------------------------------------------------- boot */
  loadState().then(function () {
    if (S.st.has_identity) { startEvents(); loadNet().catch(function () {}); loadConvs().catch(function () {}); }
    if (S.st.has_identity && !location.hash) go("home");
    var r = route().name;
    if (!S.st.has_identity && (r === "home" || !r)) location.hash = "#/welcome";
    render();
    setInterval(function () { if (S.st && S.st.has_identity) { loadNet().catch(function () {}); } }, 15000);
    window.addEventListener("hashchange", function () { if (S.st && S.st.has_identity) startEvents(); });
  }).catch(function (e) { view.innerHTML = '<div class="card"><h2>Cannot reach the local engine</h2><p>' + esc(e.message) + '</p></div>'; });
  window.gcStartEvents = startEvents;
})();
