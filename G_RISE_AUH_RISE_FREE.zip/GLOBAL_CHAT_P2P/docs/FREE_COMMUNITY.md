# G-rise — Free community model

G-rise by AUH rise is intended to be free for every user.

## Product policy

- No Premium or Business subscription tiers.
- No in-app purchases, paid upgrades, or paid feature gates.
- No free-trial timers or demo subscription state.
- No advertisements, sponsorship cards, or ad SDK integration.
- No payment-verification backend is required for the free model.
- Core peer-to-peer messaging and networking must not depend on a billing or advertising service.

## Features without a paywall

All features currently implemented in the app are available without payment. Capabilities previously described as Premium or Business ideas—such as additional profile customization, business/community profile tools, expanded group-management tools, announcements, and community insights—must remain free if and when they are implemented. This document does not claim that every planned capability is already implemented in the current source.

## Engineering rules

1. Do not add Google Play Billing solely to unlock app features.
2. Do not add AdMob or other advertising SDKs.
3. Do not gate features on purchase status, trial status, subscription status, or payment state.
4. Retain reasonable technical protections against spam, abuse, resource exhaustion, and network attacks. These are safety protections, not paid usage limits.
5. Keep P2P message contents and private keys out of any optional operational service.

## Android WebView storage

DOM storage remains enabled in `MainActivity` for ordinary web-app functionality. It is not used as a subscription or entitlement store.
