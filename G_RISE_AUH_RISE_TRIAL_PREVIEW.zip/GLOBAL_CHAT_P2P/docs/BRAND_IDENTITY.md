# G-rise brand identity

- Product name: **G-rise**
- Product meaning: **Global Rise**
- Company / publisher brand: **AUH rise**
- Suggested app-store display name: **G-rise**
- Suggested Node companion display name: **G-rise Node**

The Android application ID (`net.globalchat.p2p`) is intentionally unchanged in this branding update.
Changing an application ID after distribution would make the renamed app install as a different app and would affect upgrade continuity.

Before public release, update the Google Play developer/publisher profile, privacy policy, support contact, app icon, screenshots, and store listing to use AUH rise / G-rise consistently.
