#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../python"
python3 -m pip install --quiet cryptography pytest 2>/dev/null || true
python3 -m pytest -q "$@"
