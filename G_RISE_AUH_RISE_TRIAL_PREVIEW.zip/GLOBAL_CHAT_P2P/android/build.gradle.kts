plugins {
    id("com.android.application") version "8.5.2" apply false
    id("com.chaquo.python") version "17.2.0" apply false
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
