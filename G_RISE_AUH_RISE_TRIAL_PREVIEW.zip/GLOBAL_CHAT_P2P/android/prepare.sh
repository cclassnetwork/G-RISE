#!/usr/bin/env bash
# Copies the Python engine into the Android project. Run from anywhere:  bash android/prepare.sh
# (GitHub Actions does this for you.)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
DEST="$HERE/app/src/main/python"
rm -rf "$DEST/gcp2p" "$DEST/gc_android.py"
mkdir -p "$DEST"
cp -r "$ROOT/python/gcp2p" "$DEST/gcp2p"
cp "$ROOT/python/gc_android.py" "$DEST/gc_android.py"
find "$DEST" -name "__pycache__" -type d -prune -exec rm -rf {} +
echo "[prepare] copied $(find "$DEST/gcp2p" -type f | wc -l) engine files into $DEST"
