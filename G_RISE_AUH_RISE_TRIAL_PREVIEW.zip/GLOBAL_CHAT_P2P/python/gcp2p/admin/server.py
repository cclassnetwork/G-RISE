"""Operator dashboard for a headless node (python -m gcp2p --admin-port 4577).

Browse to http://127.0.0.1:4577 on the machine running the node, sign in, and see:
  * how many users are online (peers this node has verified), and the node's network status
  * a map with a dot and username for every user who chose to share an approximate location
  * a table of all known users

Security: bound to 127.0.0.1 by default; username + password (scrypt hash); HttpOnly SameSite=Strict session cookie;
failed-login lockout; Origin check on POST; strict CSP; read-only (the dashboard cannot send messages or change anything).
Users who did NOT opt in are listed without a location: the node never guesses locations from IP addresses.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import threading
import time
import urllib.request

from ..engine import Engine

log = logging.getLogger("gcp2p")
WEB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
SESSION_SECONDS = 8 * 3600
MAX_FAILS, LOCK_SECONDS = 5, 900
LEAFLET = "1.9.4"
_MIME = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".css": "text/css; charset=utf-8"}
_CSP = ("default-src 'none'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' https://cdn.jsdelivr.net; "
        "img-src 'self' data: https://tile.openstreetmap.org https://*.tile.openstreetmap.org https://cdn.jsdelivr.net; connect-src 'self'; "
        "base-uri 'none'; form-action 'none'; frame-ancestors 'none'")


# ------------------------------------------------------------------ credentials
def _kdf(kind: str, password: str, salt: bytes) -> bytes:
    if kind == "scrypt":
        return hashlib.scrypt(password.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 300_000, 32)


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    kind = "scrypt" if hasattr(hashlib, "scrypt") else "pbkdf2"      # some phone Pythons are built without scrypt
    try:
        h = _kdf(kind, password, salt)
    except (ValueError, AttributeError, OSError):
        kind = "pbkdf2"
        h = _kdf(kind, password, salt)
    return f"{kind}${salt.hex()}${h.hex()}"


def check_password(password: str, stored: str) -> bool:
    try:
        kind, salt, h = stored.split("$")
        if kind not in ("scrypt", "pbkdf2"):
            return False
        return hmac.compare_digest(_kdf(kind, password, bytes.fromhex(salt)).hex(), h)
    except (ValueError, TypeError, AttributeError, OSError):
        return False


def load_or_create_credentials(data_dir: str, user: str = "admin", env_password: str | None = None):
    """Returns (user, stored_hash, generated_password_or_None).  A password in GCP2P_ADMIN_PASSWORD always wins."""
    path = os.path.join(data_dir, "admin.json")
    if env_password:
        cred = {"user": user, "hash": hash_password(env_password)}
        generated = None
    elif os.path.exists(path):
        cred = json.load(open(path))
        return cred["user"], cred["hash"], None
    else:
        generated = secrets.token_urlsafe(12)
        cred = {"user": user, "hash": hash_password(generated)}
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(cred, f)
    return cred["user"], cred["hash"], generated


# ------------------------------------------------------------------ map library (downloaded once, served locally)
def fetch_map_library(vendor_dir: str) -> None:
    """Best effort: Leaflet for the map. If it cannot be downloaded the page tries the CDN, then a plain plot."""
    os.makedirs(vendor_dir, exist_ok=True)
    for name in ("leaflet.js", "leaflet.css"):
        dest = os.path.join(vendor_dir, name)
        if os.path.exists(dest):
            continue
        try:
            with urllib.request.urlopen(f"https://cdn.jsdelivr.net/npm/leaflet@{LEAFLET}/dist/{name}", timeout=20) as r:
                data = r.read(1_000_000)
            if len(data) < 5000:
                raise ValueError("unexpectedly small")
            with open(dest + ".tmp", "wb") as f:
                f.write(data)
            os.replace(dest + ".tmp", dest)
        except Exception as exc:
            log.info("map library %s not downloaded (%s); the dashboard will use a fallback", name, exc)


class AdminServer:
    def __init__(self, engine: Engine, user: str, pw_hash: str, host: str = "127.0.0.1", port: int = 4577,
                 vendor_dir: str | None = None, clock=time.time):
        self.engine, self.user, self.pw_hash, self.host, self.port = engine, user, pw_hash, host, port
        self.vendor = vendor_dir or os.path.join(engine.data_dir, "vendor")
        self.clock = clock
        self.sessions: dict[str, float] = {}
        self.fails: dict[str, list] = {}       # ip -> [count, locked_until]
        self.server = None

    async def start(self) -> int:
        self.server = await asyncio.start_server(self._client, self.host, self.port)
        self.port = self.server.sockets[0].getsockname()[1]
        threading.Thread(target=fetch_map_library, args=(self.vendor,), daemon=True).start()
        return self.port

    async def stop(self) -> None:
        if self.server:
            self.server.close()

    # ------------------------------------------------------------------ http plumbing
    async def _client(self, reader, writer):
        try:
            head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 10)
            if len(head) > 16384:
                return await self._send(writer, 431, b"headers too large", "text/plain")
            lines = head.decode("latin-1").split("\r\n")
            method, target, _ = lines[0].split(" ", 2)
            hd = {}
            for ln in lines[1:]:
                if ":" in ln:
                    k, v = ln.split(":", 1)
                    hd[k.strip().lower()] = v.strip()
            loopback = self.host in ("127.0.0.1", "localhost", "::1")
            hostname = hd.get("host", "").rpartition(":")[0] or hd.get("host", "")
            if loopback and hostname not in ("127.0.0.1", "localhost", "[::1]"):
                return await self._send(writer, 403, b"bad host", "text/plain")
            n = int(hd.get("content-length", "0") or 0)
            if n < 0 or n > 4096:
                return await self._send(writer, 413, b"too large", "text/plain")
            body = await asyncio.wait_for(reader.readexactly(n), 10) if n else b""
            path = target.split("?", 1)[0]
            ip = (writer.get_extra_info("peername") or ("?",))[0]
            await self._route(writer, method, path, hd, body, ip)
        except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError, ValueError, asyncio.LimitOverrunError):
            pass
        except Exception:
            log.exception("admin error")
        finally:
            try:
                writer.close()
            except Exception:
                pass

    async def _send(self, writer, status, data: bytes, ctype="application/json", extra="") -> None:
        reason = {200: "OK", 204: "No Content", 302: "Found", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
                  405: "Method Not Allowed", 413: "Payload Too Large", 429: "Too Many Requests", 431: "Header Fields Too Large"}.get(status, "OK")
        writer.write((f"HTTP/1.1 {status} {reason}\r\nContent-Type: {ctype}\r\nContent-Length: {len(data)}\r\nCache-Control: no-store\r\n"
                      f"Content-Security-Policy: {_CSP}\r\nReferrer-Policy: strict-origin-when-cross-origin\r\nX-Content-Type-Options: nosniff\r\n"
                      f"X-Frame-Options: DENY\r\n{extra}Connection: close\r\n\r\n").encode() + data)
        await writer.drain()

    async def _json(self, writer, status, obj, extra=""):
        await self._send(writer, status, json.dumps(obj, separators=(",", ":")).encode(), extra=extra)

    # ------------------------------------------------------------------ auth
    def _session(self, hd) -> bool:
        m = re.search(r"(?:^|;\s*)gc_admin=([A-Za-z0-9_\-]{20,64})", hd.get("cookie", ""))
        if not m:
            return False
        exp = self.sessions.get(m.group(1))
        if not exp or exp < self.clock():
            self.sessions.pop(m.group(1), None)
            return False
        return True

    def _same_origin(self, hd) -> bool:
        o = hd.get("origin")
        return o is None or o.split("://", 1)[-1] == hd.get("host", "")

    async def _login(self, writer, hd, body, ip):
        now = self.clock()
        f = self.fails.get(ip, [0, 0])
        if f[1] > now:
            return await self._json(writer, 429, {"error": f"Too many attempts. Try again in {int(f[1] - now) // 60 + 1} minutes."})
        try:
            d = json.loads(body.decode())
            u, p = str(d.get("user", "")), str(d.get("password", ""))
        except ValueError:
            return await self._json(writer, 400, {"error": "bad request"})
        ok_user = hmac.compare_digest(u.encode(), self.user.encode())
        ok_pw = await asyncio.get_event_loop().run_in_executor(None, check_password, p[:200], self.pw_hash)
        if not (ok_user and ok_pw):
            f[0] += 1
            if f[0] >= MAX_FAILS:
                f = [0, now + LOCK_SECONDS]
            self.fails[ip] = f
            log.warning("admin login failed from %s", ip)
            return await self._json(writer, 401, {"error": "Wrong username or password."})
        self.fails.pop(ip, None)
        tok = secrets.token_urlsafe(32)
        self.sessions = {t: e for t, e in self.sessions.items() if e > now}
        self.sessions[tok] = now + SESSION_SECONDS
        await self._json(writer, 200, {"ok": True},
                         extra=f"Set-Cookie: gc_admin={tok}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_SECONDS}\r\n")

    async def _route(self, writer, method, path, hd, body, ip):
        if path in ("/", "/admin"):            # relative links in the page need the trailing slash
            return await self._send(writer, 302, b"", "text/plain", extra="Location: /admin/\r\n")
        if method == "POST" and path == "/admin/api/login":
            if not self._same_origin(hd):
                return await self._json(writer, 403, {"error": "bad origin"})
            return await self._login(writer, hd, body, ip)
        if method == "POST" and path == "/admin/api/logout":
            if not self._same_origin(hd):
                return await self._json(writer, 403, {"error": "bad origin"})
            m = re.search(r"gc_admin=([A-Za-z0-9_\-]+)", hd.get("cookie", ""))
            if m:
                self.sessions.pop(m.group(1), None)
            return await self._json(writer, 200, {"ok": True}, extra="Set-Cookie: gc_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0\r\n")
        if method != "GET":
            return await self._json(writer, 405, {"error": "method not allowed"})
        if path == "/admin/api/summary":
            if not self._session(hd):
                return await self._json(writer, 401, {"error": "sign in"})
            return await self._json(writer, 200, self.summary())
        if path == "/admin/api/session":
            return await self._json(writer, 200, {"signed_in": self._session(hd)})
        m = re.match(r"^/admin/(vendor/)?([A-Za-z0-9_.\-]{0,40})$", path)
        if m:
            name = m.group(2) or "admin.html"
            root = self.vendor if m.group(1) else WEB
            ext = os.path.splitext(name)[1].lower()
            fp = os.path.join(root, name)
            if ext in _MIME and os.path.isfile(fp):
                return await self._send(writer, 200, open(fp, "rb").read(), _MIME[ext])
        await self._json(writer, 404, {"error": "not found"})

    # ------------------------------------------------------------------ data
    def summary(self) -> dict:
        eng = self.engine
        node = eng.node
        peers = node.presence.directory() if node else []
        users = [{"peer_id": p["peer_id"], "username": p["username"], "handle": p["handle"], "state": p["state"], "via": p["via"],
                  "age": p["age"], "loc": p.get("loc")} for p in peers]
        count = lambda s: sum(1 for u in users if u["state"] == s)   # noqa: E731
        net = node.network_status() if node else {}
        own = eng.state()
        return {
            "now": time.time(),
            "node": {"peer_id": own.get("peer_id"), "handle": own.get("handle"), "reachability": net.get("reachability"),
                     "connections": net.get("connections", 0), "direct": net.get("direct", 0), "relayed": net.get("relayed", 0),
                     "relay_clients": net.get("relay_clients", 0), "mailbox_held": net.get("mailbox_held", 0),
                     "location": node.location if node else None},
            "totals": {"online": count("online"), "checking": count("checking"), "unreachable": count("unreachable"),
                       "offline": count("offline"), "known": len(users), "with_location": sum(1 for u in users if u["loc"])},
            "users": users,
            "note": "Counts cover peers whose signed presence reached this node. A decentralised network has no complete user list.",
        }
