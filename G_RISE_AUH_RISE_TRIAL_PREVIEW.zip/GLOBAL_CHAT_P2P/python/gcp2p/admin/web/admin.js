"use strict";
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var COLORS = { online: "#2be38c", checking: "#f5b73b", unreachable: "#ff5d6c", offline: "#6b7a99" };
  var map = null, layer = null, leafletState = "loading", last = null, timer = null;

  function post(path, body) {
    return fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}), cache: "no-store" })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || "Error " + r.status); return j; }); });
  }
  function get(path) {
    return fetch(path, { cache: "no-store" }).then(function (r) { return r.json().then(function (j) { if (!r.ok) { var e = new Error(j.error || r.status); e.status = r.status; throw e; } return j; }); });
  }
  function ago(s) { if (s < 60) return "now"; if (s < 3600) return Math.round(s / 60) + " min ago"; if (s < 86400) return Math.round(s / 3600) + " h ago"; return Math.round(s / 86400) + " d ago"; }
  function show(signedIn) { $("login").hidden = signedIn; $("dash").hidden = !signedIn; }

  /* ---------------------------------------------------------------- map: Leaflet (local file, then CDN), else a plain plot */
  function addScript(src, ok, fail) { var s = document.createElement("script"); s.src = src; s.onload = ok; s.onerror = fail; document.head.appendChild(s); }
  function addCss(href) { var l = document.createElement("link"); l.rel = "stylesheet"; l.href = href; document.head.appendChild(l); }
  function loadLeaflet() {
    addCss("vendor/leaflet.css");
    addScript("vendor/leaflet.js", ready, function () {
      addCss("https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css");
      addScript("https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js", ready, function () { leafletState = "none"; draw(); });
    });
    function ready() { leafletState = window.L ? "ok" : "none"; draw(); }
  }
  function drawLeaflet(us) {
    if (!map) {
      map = L.map("map", { worldCopyJump: true, minZoom: 1 }).setView([15, 10], 2);
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 18, attribution: "&copy; OpenStreetMap contributors" }).addTo(map);
      layer = L.layerGroup().addTo(map);
    }
    layer.clearLayers();
    var pts = [];
    us.forEach(function (u) {
      var m = L.circleMarker(u.loc, { radius: 8, color: "#ffffff", weight: 2, fillColor: COLORS[u.state] || COLORS.offline, fillOpacity: 0.95 });
      m.bindTooltip(u.username, { permanent: true, direction: "top", offset: [0, -8], className: "gcname" });
      m.addTo(layer); pts.push(u.loc);
    });
    if (pts.length && !map._fitted) { map.fitBounds(pts, { maxZoom: 6, padding: [40, 40] }); map._fitted = true; }
    setTimeout(function () { map.invalidateSize(); }, 50);
  }
  function drawPlain(us) {
    var box = $("map"), c = box.querySelector("canvas");
    if (!c) { box.innerHTML = ""; c = document.createElement("canvas"); box.appendChild(c); }
    var w = c.width = box.clientWidth, h = c.height = box.clientHeight, g = c.getContext("2d");
    g.fillStyle = "#0b1328"; g.fillRect(0, 0, w, h);
    g.strokeStyle = "#1c2e57"; g.fillStyle = "#6b7a99"; g.font = "11px sans-serif"; g.lineWidth = 1;
    for (var lon = -180; lon <= 180; lon += 30) { var x = (lon + 180) / 360 * w; g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); g.fillText(lon, x + 2, h - 3); }
    for (var lat = -90; lat <= 90; lat += 30) { var y = (90 - lat) / 180 * h; g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); g.fillText(lat, 2, y - 2); }
    us.forEach(function (u) {
      var x = (u.loc[1] + 180) / 360 * w, y = (90 - u.loc[0]) / 180 * h;
      g.beginPath(); g.arc(x, y, 7, 0, 7); g.fillStyle = COLORS[u.state] || COLORS.offline; g.fill(); g.strokeStyle = "#fff"; g.lineWidth = 2; g.stroke();
      g.fillStyle = "#e8f0ff"; g.font = "bold 12px sans-serif"; g.fillText(u.username, x + 10, y + 4);
    });
    g.fillStyle = "#8da2c8"; g.font = "12px sans-serif"; g.fillText("Simple plot (map library not available). Latitude / longitude grid.", 8, 14);
  }
  function draw() {
    if (!last) return;
    var us = last.users.filter(function (u) { return u.loc; });
    if (last.node.location) us = us.concat([{ username: (last.node.handle || "this node") + " (this node)", state: "online", loc: last.node.location }]);
    $("mapnote").textContent = "- " + us.length + " of " + (last.totals.known + (last.node.location ? 1 : 0)) + " share a location";
    if (leafletState === "ok") drawLeaflet(us); else if (leafletState === "none") drawPlain(us);
  }

  /* ---------------------------------------------------------------- dashboard */
  function render(d) {
    last = d; var t = d.totals, n = d.node;
    $("me").textContent = "This node: " + (n.handle || "") + " - " + (n.reachability || "unknown") + " reachability";
    $("tiles").innerHTML = "";
    [["big", t.online, "Users online now"], ["", t.known, "Users known to this node"], ["", t.unreachable, "Unreachable"], ["", t.with_location, "Shown on the map"],
     ["", n.connections, "Connections (" + n.direct + " direct, " + n.relayed + " relayed)"], ["", n.relay_clients, "Phones using this node as relay"]].forEach(function (x) {
      var el = document.createElement("div"); el.className = "tile " + x[0]; var b = document.createElement("b"); b.textContent = x[1]; var s = document.createElement("span"); s.textContent = x[2];
      el.appendChild(b); el.appendChild(s); $("tiles").appendChild(el);
    });
    var tb = $("tb").querySelector("tbody"); tb.innerHTML = "";
    d.users.forEach(function (u) {
      var tr = document.createElement("tr");
      [u.handle, null, u.via === "none" ? "-" : u.via, ago(u.age), u.loc ? u.loc[0] + ", " + u.loc[1] : "not shared"].forEach(function (v, i) {
        var td = document.createElement("td");
        if (i === 1) { var sp = document.createElement("span"); sp.className = "st " + u.state; sp.textContent = u.state; td.appendChild(sp); } else td.textContent = v;
        tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
    if (!d.users.length) { var r = document.createElement("tr"), td = document.createElement("td"); td.colSpan = 5; td.className = "dim"; td.textContent = "No other users seen yet."; r.appendChild(td); tb.appendChild(r); }
    $("note").textContent = d.note + " Only users who chose to share an approximate location (about 11 km precision) appear on the map.";
    draw();
  }
  function refresh() {
    get("/admin/api/summary").then(render).catch(function (e) { if (e.status === 401) { clearInterval(timer); show(false); } });
  }
  function enter() { show(true); if (!window.__ll) { window.__ll = 1; loadLeaflet(); } refresh(); clearInterval(timer); timer = setInterval(refresh, 10000); }

  $("lf").addEventListener("submit", function (ev) {
    ev.preventDefault(); $("le").textContent = "";
    post("/admin/api/login", { user: $("u").value, password: $("p").value }).then(function () { $("p").value = ""; enter(); })
      .catch(function (e) { $("le").textContent = e.message; });
  });
  $("lo").addEventListener("click", function () { post("/admin/api/logout").then(function () { clearInterval(timer); show(false); }); });
  get("/admin/api/session").then(function (s) { if (s.signed_in) enter(); else show(false); }).catch(function () { show(false); });
})();
