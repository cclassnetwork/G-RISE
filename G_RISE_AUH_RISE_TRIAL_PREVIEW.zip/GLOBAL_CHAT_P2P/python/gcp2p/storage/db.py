"""Local SQLite storage.  Everything lives on the device; there is no server."""
from __future__ import annotations

import json
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS identity (id INTEGER PRIMARY KEY CHECK (id = 1), wrapped BLOB NOT NULL);
CREATE TABLE IF NOT EXISTS peers (
  peer_id TEXT PRIMARY KEY, pub BLOB, xpk BLOB, username TEXT,
  addrs TEXT NOT NULL DEFAULT '[]', last_seen REAL NOT NULL DEFAULT 0,
  failures INTEGER NOT NULL DEFAULT 0, saved INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS bootstrap (addr TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS dm (
  id TEXT PRIMARY KEY, peer TEXT NOT NULL, dir TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'msg',
  body TEXT NOT NULL, ts REAL NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
  next_try REAL NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '', read INTEGER NOT NULL DEFAULT 1);
CREATE INDEX IF NOT EXISTS dm_peer ON dm(peer, ts);
CREATE TABLE IF NOT EXISTS group_msgs (
  id TEXT PRIMARY KEY, room TEXT NOT NULL, sender TEXT NOT NULL, username TEXT NOT NULL,
  ts REAL NOT NULL, body TEXT NOT NULL, mine INTEGER NOT NULL DEFAULT 0, recv REAL NOT NULL, raw TEXT NOT NULL DEFAULT '');
CREATE INDEX IF NOT EXISTS grp_room ON group_msgs(room, ts);
CREATE TABLE IF NOT EXISTS rooms (
  gid TEXT PRIMARY KEY, name TEXT NOT NULL, descr TEXT NOT NULL DEFAULT '', owner TEXT NOT NULL, kind TEXT NOT NULL,
  key BLOB, joined INTEGER NOT NULL DEFAULT 0, mine INTEGER NOT NULL DEFAULT 0, ts REAL NOT NULL,
  last_ts REAL NOT NULL DEFAULT 0, closed INTEGER NOT NULL DEFAULT 0, raw TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS media (
  id TEXT PRIMARY KEY, peer TEXT NOT NULL, dir TEXT NOT NULL, kind TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL,
  sha TEXT NOT NULL, once INTEGER NOT NULL DEFAULT 0, caption TEXT NOT NULL DEFAULT '', chunks INTEGER NOT NULL,
  fk BLOB NOT NULL, state TEXT NOT NULL, viewed INTEGER NOT NULL DEFAULT 0, ts REAL NOT NULL, note TEXT NOT NULL DEFAULT '');
CREATE INDEX IF NOT EXISTS media_peer ON media(peer, ts);
CREATE TABLE IF NOT EXISTS mailbox (
  id TEXT PRIMARY KEY, recipient TEXT NOT NULL, env TEXT NOT NULL, expires REAL NOT NULL,
  putter TEXT NOT NULL, size INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS mbox_rcpt ON mailbox(recipient);
CREATE TABLE IF NOT EXISTS records (
  key TEXT PRIMARY KEY, kind TEXT NOT NULL, value TEXT NOT NULL, ts REAL NOT NULL, expires REAL NOT NULL);
"""


class Database:
    def __init__(self, path: str = ":memory:"):
        self.path = path
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        with self._lock:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA foreign_keys=ON")
            self.conn.executescript(SCHEMA)

    def close(self) -> None:
        with self._lock:
            self.conn.close()

    def _q(self, sql: str, args=()):
        with self._lock:
            return self.conn.execute(sql, args).fetchall()

    def _x(self, sql: str, args=()):
        with self._lock:
            return self.conn.execute(sql, args)

    # ---- key/value settings -------------------------------------------------
    def get(self, k: str, default=None):
        r = self._q("SELECT v FROM kv WHERE k=?", (k,))
        return json.loads(r[0]["v"]) if r else default

    def set(self, k: str, v) -> None:
        self._x("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, json.dumps(v)))

    # ---- identity ------------------------------------------------------------
    def get_identity_blob(self):
        r = self._q("SELECT wrapped FROM identity WHERE id=1")
        return bytes(r[0]["wrapped"]) if r else None

    def put_identity_blob(self, blob: bytes) -> None:
        self._x("INSERT OR REPLACE INTO identity(id, wrapped) VALUES(1, ?)", (blob,))

    # ---- peers --------------------------------------------------------------
    def upsert_peer(self, peer_id, pub=None, xpk=None, username=None, addrs=None, seen=None, saved=None):
        with self._lock:
            row = self._q("SELECT * FROM peers WHERE peer_id=?", (peer_id,))
            if not row:
                self._x("INSERT INTO peers(peer_id,pub,xpk,username,addrs,last_seen,saved) VALUES(?,?,?,?,?,?,?)",
                        (peer_id, pub, xpk, username, json.dumps(addrs or []), seen or 0, 1 if saved else 0))
                return
            r = row[0]
            self._x("UPDATE peers SET pub=?, xpk=?, username=?, addrs=?, last_seen=?, saved=? WHERE peer_id=?",
                    (pub or r["pub"], xpk or r["xpk"], username or r["username"],
                     json.dumps(addrs) if addrs else r["addrs"], max(seen or 0, r["last_seen"]),
                     r["saved"] if saved is None else (1 if saved else 0), peer_id))

    def get_peer(self, peer_id):
        r = self._q("SELECT * FROM peers WHERE peer_id=?", (peer_id,))
        return self._peer(r[0]) if r else None

    def list_peers(self, limit=500):
        return [self._peer(r) for r in self._q("SELECT * FROM peers ORDER BY last_seen DESC LIMIT ?", (limit,))]

    def mark_peer_failure(self, peer_id, ok: bool):
        if ok:
            self._x("UPDATE peers SET failures=0 WHERE peer_id=?", (peer_id,))
        else:
            self._x("UPDATE peers SET failures=failures+1 WHERE peer_id=?", (peer_id,))

    @staticmethod
    def _peer(r):
        d = dict(r)
        d["addrs"] = json.loads(d["addrs"] or "[]")
        return d

    # ---- bootstrap list -------------------------------------------------------
    def add_bootstrap(self, addr: str):
        self._x("INSERT OR IGNORE INTO bootstrap(addr) VALUES(?)", (addr,))

    def remove_bootstrap(self, addr: str):
        self._x("DELETE FROM bootstrap WHERE addr=?", (addr,))

    def list_bootstrap(self):
        return [r["addr"] for r in self._q("SELECT addr FROM bootstrap ORDER BY addr")]

    # ---- direct messages ------------------------------------------------------
    def dm_insert(self, id, peer, dir, body, ts, status, kind="msg", next_try=0.0, read=1):
        cur = self._x("INSERT OR IGNORE INTO dm(id,peer,dir,kind,body,ts,status,next_try,read) VALUES(?,?,?,?,?,?,?,?,?)",
                      (id, peer, dir, kind, body, ts, status, next_try, read))
        return cur.rowcount == 1

    def dm_get(self, id):
        r = self._q("SELECT * FROM dm WHERE id=?", (id,))
        return dict(r[0]) if r else None

    def dm_exists(self, id) -> bool:
        return bool(self._q("SELECT 1 FROM dm WHERE id=?", (id,)))

    def dm_update(self, id, **fields):
        if not fields:
            return
        cols = ", ".join(f"{k}=?" for k in fields)
        self._x(f"UPDATE dm SET {cols} WHERE id=?", (*fields.values(), id))

    def dm_thread(self, peer, limit=300):
        rows = self._q("SELECT * FROM dm WHERE peer=? AND kind IN ('msg','media') ORDER BY ts DESC LIMIT ?", (peer, limit))
        return [dict(r) for r in reversed(rows)]

    def dm_due(self, now, limit=20):
        rows = self._q("SELECT * FROM dm WHERE dir='out' AND status IN ('queued','sent') AND next_try<=? "
                       "ORDER BY ts LIMIT ?", (now, limit))
        return [dict(r) for r in rows]

    def dm_conversations(self):
        rows = self._q("""SELECT peer, MAX(ts) AS ts,
                 SUM(CASE WHEN dir='in' AND read=0 THEN 1 ELSE 0 END) AS unread
                 FROM dm WHERE kind IN ('msg','media') GROUP BY peer ORDER BY ts DESC""")
        out = []
        for r in rows:
            last = self._q("SELECT body, dir, status, kind FROM dm WHERE peer=? AND kind IN ('msg','media') ORDER BY ts DESC LIMIT 1", (r["peer"],))
            out.append({"peer": r["peer"], "ts": r["ts"], "unread": r["unread"] or 0,
                        "last": last[0]["body"] if last else "", "dir": last[0]["dir"] if last else "in",
                        "last_kind": last[0]["kind"] if last else "msg"})
        return out

    def dm_mark_read(self, peer):
        self._x("UPDATE dm SET read=1 WHERE peer=? AND dir='in'", (peer,))

    # ---- group ---------------------------------------------------------------
    def group_insert(self, m: dict, mine: bool, now: float, display: dict | None = None) -> bool:
        """`display` carries the decrypted username/body of a private-room message; raw keeps the signed envelope."""
        d = display or m
        cur = self._x("INSERT OR IGNORE INTO group_msgs(id,room,sender,username,ts,body,mine,recv,raw) VALUES(?,?,?,?,?,?,?,?,?)",
                      (m["id"], m["room"], m["peer"], d["username"], m["ts"], d["body"], 1 if mine else 0, now,
                       json.dumps(m, separators=(",", ":"))))
        return cur.rowcount == 1

    def group_delete_room(self, room) -> None:
        self._x("DELETE FROM group_msgs WHERE room=?", (room,))

    def group_exists(self, id) -> bool:
        return bool(self._q("SELECT 1 FROM group_msgs WHERE id=?", (id,)))

    def group_list(self, room, limit=300):
        rows = self._q("SELECT * FROM group_msgs WHERE room=? ORDER BY ts DESC LIMIT ?", (room, limit))
        return [dict(r) for r in reversed(rows)]

    def group_recent_ids(self, room, limit=200):
        return [r["id"] for r in self._q("SELECT id FROM group_msgs WHERE room=? ORDER BY ts DESC LIMIT ?", (room, limit))]

    def group_since_raw(self, room, since, exclude, limit=100):
        rows = self._q("SELECT id, raw FROM group_msgs WHERE room=? AND ts>=? AND raw!='' ORDER BY ts DESC LIMIT ?",
                       (room, since, limit + len(exclude)))
        return [json.loads(r["raw"]) for r in rows if r["id"] not in exclude][:limit]

    # ---- media (photos / videos) ---------------------------------------------------
    def media_get(self, id):
        r = self._q("SELECT * FROM media WHERE id=?", (id,))
        return dict(r[0]) if r else None

    def media_put(self, id, peer, dir, kind, mime, size, sha, once, caption, chunks, fk, state, ts):
        cur = self._x("INSERT OR IGNORE INTO media(id,peer,dir,kind,mime,size,sha,once,caption,chunks,fk,state,ts) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (id, peer, dir, kind, mime, size, sha, 1 if once else 0, caption, chunks, fk, state, ts))
        return cur.rowcount == 1

    def media_set(self, id, **kw):
        for k in kw:
            if k not in ("state", "viewed", "note"):
                raise ValueError(k)
        if kw:
            self._x(f"UPDATE media SET {','.join(k + '=?' for k in kw)} WHERE id=?", (*kw.values(), id))

    def media_list(self, where="1=1", args=()):
        return [dict(r) for r in self._q(f"SELECT * FROM media WHERE {where} ORDER BY ts", args)]

    def media_bytes_from(self, peer, since):
        r = self._q("SELECT COALESCE(SUM(size),0) s FROM media WHERE peer=? AND dir='in' AND ts>?", (peer, since))
        return r[0]["s"]

    # ---- user-created rooms --------------------------------------------------
    def room_get(self, gid):
        r = self._q("SELECT * FROM rooms WHERE gid=?", (gid,))
        return dict(r[0]) if r else None

    def room_put(self, gid, name, descr, owner, kind, ts, *, key=None, joined=0, mine=0, closed=0, raw=""):
        self._x("""INSERT INTO rooms(gid,name,descr,owner,kind,key,joined,mine,ts,closed,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(gid) DO UPDATE SET name=excluded.name, descr=excluded.descr, ts=excluded.ts, closed=excluded.closed, raw=excluded.raw""",
                (gid, name, descr, owner, kind, key, joined, mine, ts, closed, raw))

    def room_set(self, gid, **kw) -> None:
        for k in kw:
            if k not in ("joined", "key", "last_ts", "closed"):
                raise ValueError(k)
        if kw:
            self._x(f"UPDATE rooms SET {','.join(k + '=?' for k in kw)} WHERE gid=?", (*kw.values(), gid))

    def room_list(self):
        return [dict(r) for r in self._q("SELECT * FROM rooms ORDER BY joined DESC, last_ts DESC, ts DESC")]

    def room_delete(self, gid) -> None:
        self._x("DELETE FROM rooms WHERE gid=?", (gid,))

    def room_public_raw(self, limit=100):
        rows = self._q("SELECT raw FROM rooms WHERE kind='public' AND raw!='' ORDER BY (closed=0) DESC, last_ts DESC, ts DESC LIMIT ?", (limit,))
        return [json.loads(r["raw"]) for r in rows]

    def room_trim(self, keep=400) -> None:
        """Bound the directory: forget the least active public rooms that I am not in."""
        self._x("""DELETE FROM rooms WHERE gid IN (SELECT gid FROM rooms WHERE joined=0 AND mine=0 AND kind='public'
                   ORDER BY max(last_ts, ts) DESC LIMIT -1 OFFSET ?)""", (keep,))

    # ---- store-and-forward mailbox -------------------------------------------
    def mbox_put(self, id, recipient, env, expires, putter, size):
        cur = self._x("INSERT OR IGNORE INTO mailbox(id,recipient,env,expires,putter,size) VALUES(?,?,?,?,?,?)",
                      (id, recipient, env, expires, putter, size))
        return cur.rowcount == 1

    def mbox_count(self, recipient=None):
        if recipient:
            return self._q("SELECT COUNT(*) c FROM mailbox WHERE recipient=?", (recipient,))[0]["c"]
        return self._q("SELECT COUNT(*) c FROM mailbox")[0]["c"]

    def mbox_get(self, recipient, now, limit=50):
        return [dict(r) for r in self._q("SELECT id, env FROM mailbox WHERE recipient=? AND expires>? LIMIT ?",
                                         (recipient, now, limit))]

    def mbox_delete(self, recipient, ids):
        for i in ids[:200]:
            self._x("DELETE FROM mailbox WHERE id=? AND recipient=?", (i, recipient))

    def mbox_expire(self, now):
        self._x("DELETE FROM mailbox WHERE expires<=?", (now,))

    # ---- DHT records ---------------------------------------------------------
    def rec_put(self, key, kind, value: dict, ts, expires) -> bool:
        with self._lock:
            r = self._q("SELECT ts FROM records WHERE key=?", (key,))
            if r and r[0]["ts"] >= ts:
                return False
            self._x("INSERT OR REPLACE INTO records(key,kind,value,ts,expires) VALUES(?,?,?,?,?)",
                    (key, kind, json.dumps(value), ts, expires))
            return True

    def rec_get(self, key, now):
        r = self._q("SELECT value FROM records WHERE key=? AND expires>?", (key, now))
        return json.loads(r[0]["value"]) if r else None

    def rec_count(self):
        return self._q("SELECT COUNT(*) c FROM records")[0]["c"]

    def rec_expire(self, now):
        self._x("DELETE FROM records WHERE expires<=?", (now,))
        # hard cap
        self._x("DELETE FROM records WHERE key IN (SELECT key FROM records ORDER BY ts ASC LIMIT "
                "MAX(0,(SELECT COUNT(*) FROM records)-5000))")


def now() -> float:
    return time.time()
