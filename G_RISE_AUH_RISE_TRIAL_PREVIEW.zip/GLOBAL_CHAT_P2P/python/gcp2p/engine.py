"""Engine: owns storage, identity and the running node.  The local API and the
Android entry point talk only to this class."""
from __future__ import annotations

import asyncio
import logging
import os
import re
import stat

from .discovery.lan import LanDiscovery
from .encryption import crypto
from .identity.identity import Identity, IdentityError, fingerprint_of, handle, validate_username
from .messaging.media import MediaError
from .messaging.dm import DmError
from .group_chat.group import GroupError, ROOM
from .group_chat.rooms import RoomError
from .networking.node import Node
from .storage.db import Database

log = logging.getLogger("gcp2p")

DEFAULT_SETTINGS = {
    "listen": True,            # accept inbound connections
    "store_forward": True,     # hold encrypted offline messages for others
    "relay": True,             # relay for peers behind NAT (only if publicly reachable)
    "lan": True,               # discover peers on the local Wi-Fi
    "notifications": True,
    "background": True,        # Android: keep running in background (foreground service)
}
_BOOT_RE = re.compile(r"^(gc[a-z2-7]{32}@)?[A-Za-z0-9.\-]{1,253}:\d{1,5}$")


class EngineError(Exception):
    pass


def parse_peer_address(text: str) -> str:
    """Accept 'host:port', 'gc...@host:port' or 'gcp2p://gc...@host:port'."""
    t = (text or "").strip()
    if t.startswith("gcp2p://"):
        t = t[len("gcp2p://"):]
    if not _BOOT_RE.match(t):
        raise EngineError("Use the form host:port or gcp2p://peerid@host:port")
    port = int(t.rpartition(":")[2])
    if not (0 < port < 65536):
        raise EngineError("Port must be 1-65535.")
    return t


class Engine:
    def __init__(self, data_dir: str, storage_key: bytes | None = None, host: str = "0.0.0.0",
                 lan_port: int | None = None, port: int | None = None):
        os.makedirs(data_dir, exist_ok=True)
        self.data_dir = data_dir
        self.host = host
        self.db = Database(os.path.join(data_dir, "gcp2p.db"))
        self.storage_key = storage_key or self._file_key()
        self.identity: Identity | None = None
        self.node: Node | None = None
        self.subscribers: list[asyncio.Queue] = []
        self.notify_cb = None
        self.lan_port = lan_port
        self.fixed_port = port            # headless nodes (bootstrap/relay) use a fixed, forwardable port
        self._lock = asyncio.Lock()

    # ---------------------------------------------------------------- keys
    def _file_key(self) -> bytes:
        """Desktop/Termux fallback.  On Android the key comes from the Android Keystore."""
        path = os.path.join(self.data_dir, "storage.key")
        if os.path.exists(path):
            return open(path, "rb").read()
        key = os.urandom(32)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(key)
        return key

    # ---------------------------------------------------------------- lifecycle
    async def start(self) -> None:
        blob = self.db.get_identity_blob()
        if blob:
            try:
                raw = crypto.unwrap(self.storage_key, blob, b"gcp2p-identity")
            except crypto.CryptoError as exc:
                raise EngineError("Identity cannot be unlocked with this device key.") from exc
            self.identity = Identity.from_bytes(raw)
            await self._start_node()

    async def stop(self) -> None:
        if self.node:
            await self.node.stop()
            self.node = None
        self.db.close()

    async def _start_node(self) -> None:
        s = self.settings()
        username = self.db.get("username") or "user" + self.identity.peer_id[-4:]
        node = Node(self.identity, username, self.db, listen=s["listen"], host=self.host,
                    port=self.fixed_port or self.db.get("port") or 0, store_forward=s["store_forward"], relay_service=s["relay"],
                    media_dir=os.path.join(self.data_dir, "media"), storage_key=self.storage_key)
        node.location = self.db.get("location") or None
        node.subscribers = self.subscribers
        node.notifier = self._on_notify
        await node.start()
        if node.listen:
            self.db.set("port", node.port)
        self.node = node
        if s["lan"] and node.listen:
            try:
                kw = {"bind_port": self.lan_port} if self.lan_port else {}
                node.lan = LanDiscovery(node, **kw)
                await node.lan.start()
            except OSError as exc:
                log.warning("LAN discovery unavailable: %s", exc)
                node.lan = None
        self.emit("state")

    def emit(self, kind: str, data=None) -> None:
        for q in list(self.subscribers):
            try:
                q.put_nowait({"type": kind, "data": data or {}})
            except asyncio.QueueFull:
                pass

    def _on_notify(self, peer, name, text, private):
        if self.notify_cb and self.settings().get("notifications", True):
            self.notify_cb(peer, name, text, private)

    # ---------------------------------------------------------------- identity
    async def create_identity(self, username: str = "") -> dict:
        """Create the anonymous identity.  Username is optional here (the UI asks for it in the next step)."""
        async with self._lock:
            if self.identity is not None:
                raise EngineError("An identity already exists on this device.")
            ident = Identity.generate()
            if (username or "").strip():
                try:
                    username = validate_username(username)
                except IdentityError as exc:
                    raise EngineError(str(exc)) from exc
            else:
                username = "user" + ident.peer_id[-4:]
            self.db.put_identity_blob(crypto.wrap(self.storage_key, ident.to_bytes(), b"gcp2p-identity"))
            self.db.set("username", username)
            self.identity = ident
            await self._start_node()
        return self.state()

    async def set_username(self, username: str) -> dict:
        if self.node is None:
            raise EngineError("Create an identity first.")
        try:
            username = validate_username(username)
        except IdentityError as exc:
            raise EngineError(str(exc)) from exc
        self.db.set("username", username)
        self.node.set_username(username)
        await self.node.presence.publish()          # tell the network; peer id is unchanged
        self.emit("state")
        return self.state()

    # ---------------------------------------------------------------- optional map location
    def get_location(self) -> dict:
        loc = self.db.get("location")
        return {"shared": bool(loc), "lat": loc[0] if loc else None, "lon": loc[1] if loc else None,
                "label": self.db.get("location_label") or ""}

    async def set_location(self, lat, lon, label: str = "") -> dict:
        """lat/lon None = stop sharing.  Stored and sent only as 0.1-degree (about 11 km) coordinates."""
        if self.node is None:
            raise EngineError("Create an identity first.")
        if lat is None or lon is None:
            self.db.set("location", None); self.db.set("location_label", "")
            self.node.location = None
        else:
            if (isinstance(lat, bool) or isinstance(lon, bool) or not isinstance(lat, (int, float)) or not isinstance(lon, (int, float))
                    or not (-90 <= lat <= 90 and -180 <= lon <= 180)):
                raise EngineError("Latitude must be -90..90 and longitude -180..180.")
            loc = [round(float(lat), 1), round(float(lon), 1)]
            self.db.set("location", loc)
            self.db.set("location_label", str(label or "")[:40])
            self.node.location = loc
        await self.node.presence.publish()
        return self.get_location()

    async def delete_identity(self) -> None:
        """Wipe this device's identity and all data (used by 'Reset')."""
        async with self._lock:
            if self.node:
                await self.node.stop()
                self.node = None
            for t in ("identity", "peers", "dm", "group_msgs", "mailbox", "records", "kv", "bootstrap"):   # kv also clears the shared location
                self.db._x(f"DELETE FROM {t}")
            self.identity = None
            self.emit("state")

    def state(self) -> dict:
        if self.identity is None:
            return {"has_identity": False}
        username = self.db.get("username") or ""
        n = self.node
        return {
            "has_identity": True, "peer_id": self.identity.peer_id, "username": username,
            "handle": handle(username, self.identity.peer_id),
            "fingerprint": self.identity.fingerprint(),
            "running": bool(n and n.started),
        }

    def identity_info(self) -> dict:
        if self.identity is None:
            raise EngineError("No identity.")
        n = self.node
        invites = [f"gcp2p://{self.identity.peer_id}@{a}" for a in (n.public_addrs if n else [])]
        return {**self.state(), "public_key": crypto.b64e(self.identity.pub), "encryption_key": crypto.b64e(self.identity.xpub),
                "signing": "Ed25519", "key_agreement": "X25519", "cipher": "ChaCha20-Poly1305",
                "storage": "Identity key is encrypted at rest with a device-bound key.", "invites": invites}

    # ---------------------------------------------------------------- settings / bootstrap
    def settings(self) -> dict:
        s = dict(DEFAULT_SETTINGS)
        s.update(self.db.get("settings", {}) or {})
        return s

    def update_settings(self, patch: dict) -> dict:
        s = self.settings()
        for k, v in (patch or {}).items():
            if k in DEFAULT_SETTINGS and isinstance(v, bool):
                s[k] = v
        self.db.set("settings", s)
        if self.node:
            self.node.store_forward = s["store_forward"]
            self.node.relay.enabled = s["relay"]
        return {**s, "restart_needed_for": ["listen", "lan"]}

    def bootstrap_list(self) -> list:
        return self.db.list_bootstrap()

    async def add_bootstrap(self, text: str) -> list:
        addr = parse_peer_address(text)
        self.db.add_bootstrap(addr)
        if self.node:
            peer, _, a = addr.rpartition("@") if "@" in addr else ("", "", addr)
            self.node.spawn(self.node.connect(a, expect_peer=peer or None))
        return self.bootstrap_list()

    def remove_bootstrap(self, addr: str) -> list:
        self.db.remove_bootstrap(addr)
        return self.bootstrap_list()

    async def connect_to(self, text: str) -> bool:
        if not self.node:
            raise EngineError("Create an identity first.")
        addr = parse_peer_address(text)
        peer, a = (addr.split("@", 1) if "@" in addr else (None, addr))
        c = await self.node.connect(a, expect_peer=peer)
        return c is not None

    # ---------------------------------------------------------------- peers / chat
    def _need_node(self) -> Node:
        if self.node is None:
            raise EngineError("Create an identity first.")
        return self.node

    def peers(self) -> list:
        return self._need_node().presence.directory()

    async def refresh_peers(self) -> list:
        n = self._need_node()
        await n._bootstrap_if_needed()
        await n.presence.refresh()
        for c in [c for c in n.conns.values() if c.ready.is_set()][:6]:
            await n.rooms.sync_from(c)
            await n.group.sync_with(c)
        await n.dm.fetch_mailbox()
        return n.presence.directory()

    def conversations(self) -> list:
        n = self._need_node()
        out = []
        for c in self.db.dm_conversations():
            p = self.db.get_peer(c["peer"]) or {}
            name = p.get("username") or c["peer"][-6:]
            out.append({**c, "username": name, "handle": handle(name, c["peer"]), "state": n.presence.state_of(c["peer"])})
        return out

    def thread(self, peer: str) -> dict:
        n = self._need_node()
        if not crypto.valid_peer_id(peer):
            raise EngineError("Invalid peer id.")
        p = self.db.get_peer(peer) or {}
        name = p.get("username") or peer[-6:]
        msgs = []
        for m in self.db.dm_thread(peer):
            item = {"id": m["id"], "dir": m["dir"], "body": m["body"], "ts": m["ts"], "status": m["status"], "note": m["note"]}
            if m["kind"] == "media":
                item["body"] = ""
                item["media"] = n.media.info(m["id"])
            msgs.append(item)
        return {"peer_id": peer, "username": name, "handle": handle(name, peer), "state": n.presence.state_of(peer),
                "fingerprint": fingerprint_of(bytes(p["pub"])) if p.get("pub") else "", "messages": msgs}

    async def send_media(self, to: str, data: bytes, mime: str, once: bool, caption: str) -> dict:
        try:
            return await self._need_node().media.send(to, data, mime, once, caption)
        except MediaError as exc:
            raise EngineError(str(exc)) from exc

    async def media_download(self, mid: str) -> dict:
        try:
            return await self._need_node().media.download(mid)
        except MediaError as exc:
            raise EngineError(str(exc)) from exc

    def media_open(self, mid: str):
        try:
            return self._need_node().media.open(mid)
        except MediaError as exc:
            raise EngineError(str(exc)) from exc

    def mark_read(self, peer: str) -> None:
        self.db.dm_mark_read(peer)

    async def send_dm(self, to: str, text: str) -> dict:
        try:
            return await self._need_node().dm.send(to, text)
        except DmError as exc:
            raise EngineError(str(exc)) from exc

    async def retry_dm(self, mid: str) -> None:
        n = self._need_node()
        row = self.db.dm_get(mid)
        if not row or row["dir"] != "out":
            raise EngineError("Unknown message.")
        self.db.dm_update(mid, status="queued", next_try=0, ts=n.now() if row["status"] == "failed" else row["ts"])
        asyncio.ensure_future(n.dm.attempt(mid))

    def group_messages(self, room: str = ROOM) -> list:
        self._need_node()
        return [{"id": m["id"], "sender": m["sender"], "username": m["username"],
                 "handle": handle(m["username"], m["sender"]), "ts": m["ts"], "body": m["body"], "mine": bool(m["mine"])}
                for m in self.db.group_list(room)]

    # ---- user-created groups -----------------------------------------------------------------------------------
    def rooms(self) -> list:
        return self._need_node().rooms.listing()

    def room_thread(self, gid: str) -> dict:
        n = self._need_node()
        try:
            d = n.rooms.detail(gid)
        except RoomError as exc:
            raise EngineError(str(exc)) from exc
        return {**d, "messages": self.group_messages(gid) if d["joined"] else []}

    async def _room(self, fn, *a):
        try:
            res = fn(*a)
            return await res if asyncio.iscoroutine(res) else res
        except (RoomError, GroupError) as exc:
            raise EngineError(str(exc)) from exc

    async def room_create(self, name, desc, kind):
        return await self._room(self._need_node().rooms.create, name, desc, kind)

    async def room_join(self, gid=None, invite=None):
        n = self._need_node()
        return await self._room(n.rooms.join_invite, invite) if invite else await self._room(n.rooms.join, gid)

    async def room_leave(self, gid):
        await self._room(self._need_node().rooms.leave, gid)
        return {"ok": True}

    async def room_close(self, gid):
        await self._room(self._need_node().rooms.close, gid)
        return {"ok": True}

    async def room_send(self, gid, text):
        return await self._room(self._need_node().group.send, text, gid)

    async def send_group(self, text: str) -> dict:
        try:
            return await self._need_node().group.send(text)
        except GroupError as exc:
            raise EngineError(str(exc)) from exc

    def network(self) -> dict:
        n = self._need_node()
        st = n.network_status()
        st["lan"] = bool(n.lan)
        st["bootstrap"] = self.bootstrap_list()
        st["known_peers"] = len(self.db.list_peers(limit=1000))
        return st
