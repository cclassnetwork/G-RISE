"""Token-bucket rate limiting used against spam and flooding."""
from __future__ import annotations

import time


class TokenBucket:
    def __init__(self, rate: float, burst: float, clock=time.monotonic):
        self.rate = rate
        self.burst = burst
        self.tokens = burst
        self.clock = clock
        self.last = clock()

    def allow(self, cost: float = 1.0) -> bool:
        now = self.clock()
        self.tokens = min(self.burst, self.tokens + (now - self.last) * self.rate)
        self.last = now
        if self.tokens >= cost:
            self.tokens -= cost
            return True
        return False


class KeyedLimiter:
    """One bucket per key (e.g. per sender peer id), bounded in size."""

    def __init__(self, rate: float, burst: float, max_keys: int = 2000, clock=time.monotonic):
        self.rate, self.burst, self.max_keys, self.clock = rate, burst, max_keys, clock
        self.buckets: dict[str, TokenBucket] = {}

    def allow(self, key: str, cost: float = 1.0) -> bool:
        b = self.buckets.get(key)
        if b is None:
            if len(self.buckets) >= self.max_keys:
                # drop the oldest entry
                self.buckets.pop(next(iter(self.buckets)))
            b = self.buckets[key] = TokenBucket(self.rate, self.burst, self.clock)
        return b.allow(cost)
