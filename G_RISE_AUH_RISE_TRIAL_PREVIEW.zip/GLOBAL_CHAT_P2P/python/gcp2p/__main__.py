"""Headless node: `python -m gcp2p --data ./node1 --port 4001 --username mynode`.

Run this on a PC / Kali / VPS to give the phone app a public bootstrap + relay
peer.  It is an ordinary peer, not a server: it cannot read anyone's messages.
"""
import argparse
import asyncio
import logging
import os
import secrets

from .api.server import ApiServer
from .admin.server import AdminServer, load_or_create_credentials
from .engine import Engine


async def amain(a):
    eng = Engine(a.data, host=a.host, port=a.port)
    await eng.start()
    if eng.identity is None:
        await eng.create_identity(a.username)
    for b in a.bootstrap:
        await eng.add_bootstrap(b)
    api = None
    if a.api_port is not None:
        token = os.environ.get("GCP2P_TOKEN") or secrets.token_hex(16)
        api = ApiServer(eng, token, port=a.api_port)
        await api.start()
        print(f"API on 127.0.0.1:{api.port}  token={token}")
    admin = None
    if a.admin_port is not None:
        user, pw_hash, generated = load_or_create_credentials(a.data, a.admin_user, os.environ.get("GCP2P_ADMIN_PASSWORD"))
        admin = AdminServer(eng, user, pw_hash, host=a.admin_host, port=a.admin_port)
        await admin.start()
        print(f"DASHBOARD: http://{'127.0.0.1' if a.admin_host == '127.0.0.1' else a.admin_host}:{admin.port}   (username: {user})")
        if generated:
            print(f"DASHBOARD PASSWORD (shown once, change it with GCP2P_ADMIN_PASSWORD=...): {generated}")
        if a.admin_host not in ("127.0.0.1", "localhost", "::1"):
            print("WARNING: the dashboard is reachable from the network over plain http. Put it behind HTTPS (Caddy/nginx) or use an SSH tunnel.")
    n = eng.node
    print(f"peer id : {eng.identity.peer_id}")
    print(f"listen  : {n.host}:{n.port}")
    print("Share this with phones (replace PUBLIC_IP):")
    print(f"  gcp2p://{eng.identity.peer_id}@PUBLIC_IP:{n.port}")
    try:
        while True:
            await asyncio.sleep(30)
            st = n.network_status()
            logging.info("conns=%d reach=%s relay_clients=%d mailbox=%d", st["connections"], st["reachability"],
                         st["relay_clients"], st["mailbox_held"])
    finally:
        await eng.stop()


def main():
    p = argparse.ArgumentParser(prog="gcp2p")
    p.add_argument("--data", default="./gcp2p-data")
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=None, help="fixed TCP listening port (default: random, remembered)")
    p.add_argument("--username", default="bootstrap")
    p.add_argument("--bootstrap", action="append", default=[])
    p.add_argument("--admin-port", type=int, default=None, help="enable the operator dashboard on this port (e.g. 4577)")
    p.add_argument("--admin-host", default="127.0.0.1", help="dashboard bind address (default 127.0.0.1 = this machine only)")
    p.add_argument("--admin-user", default="admin")
    p.add_argument("--api-port", type=int, default=None, help="enable local API on 127.0.0.1:PORT (0 = random)")
    p.add_argument("-v", "--verbose", action="store_true")
    a = p.parse_args()
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO, format="%(asctime)s %(message)s")
    try:
        asyncio.run(amain(a))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
