import asyncio, json, time
import pytest
from helpers import run, make_node, until, stop_all
from gcp2p.identity.identity import Identity
from gcp2p.networking.link import TcpLink, handshake, ChannelError
from gcp2p.networking.node import Node
from gcp2p.storage.db import Database
from gcp2p.group_chat.group import make_message
from gcp2p.encryption import crypto


def ready(n, other):
    c = n.conns.get(other.id)
    return bool(c and c.ready.is_set() and not c.closed)


# ---------------------------------------------------------------- secure channel
def test_handshake_authenticates_both_sides_and_rejects_wrong_peer():
    async def go():
        a, b = Identity.generate(), Identity.generate()
        got = {}

        async def on(reader, writer):
            got["chan"] = await handshake(TcpLink(reader, writer), b, False)
            got["msg"] = await got["chan"].recv()
        srv = await asyncio.start_server(on, "127.0.0.1", 0)
        port = srv.sockets[0].getsockname()[1]
        r, w = await asyncio.open_connection("127.0.0.1", port)
        chan = await handshake(TcpLink(r, w), a, True, expect_peer=b.peer_id)
        assert chan.remote_id == b.peer_id
        await chan.send({"t": "x", "v": 1})
        assert await until(lambda: "msg" in got)
        assert got["msg"]["v"] == 1 and got["chan"].remote_id == a.peer_id
        # expecting a different identity must fail
        r2, w2 = await asyncio.open_connection("127.0.0.1", port)
        with pytest.raises(ChannelError):
            await handshake(TcpLink(r2, w2), a, True, expect_peer=Identity.generate().peer_id)
        srv.close()
    run(go())


def test_garbage_and_tampered_traffic_is_rejected():
    async def go():
        n = await make_node("alice")
        r, w = await asyncio.open_connection("127.0.0.1", n.port)
        w.write(b"\x00\x00\x00\x05hello"); await w.drain()          # not a valid handshake
        await asyncio.sleep(0.3)
        assert not n.conns
        # valid handshake, then a corrupted ciphertext frame closes the session
        me = Identity.generate()
        r, w = await asyncio.open_connection("127.0.0.1", n.port)
        chan = await handshake(TcpLink(r, w), me, True)
        assert await until(lambda: me.peer_id in n.conns)
        w.write(b"\x00\x00\x00\x20" + b"\x01" * 32); await w.drain()
        assert await until(lambda: me.peer_id not in n.conns)
        await n.stop()
    run(go())


# ---------------------------------------------------------------- private chat
def test_private_message_end_to_end_and_status():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(a, b) and ready(b, a))
        assert await until(lambda: a.db.get_peer(b.id) and a.db.get_peer(b.id)["xpk"])
        r = await a.dm.send(b.id, "salaam bobby")
        assert await until(lambda: a.db.dm_get(r["id"])["status"] == "delivered")
        thread = b.db.dm_thread(a.id)
        assert [m["body"] for m in thread] == ["salaam bobby"] and thread[0]["dir"] == "in"
        # and back
        r2 = await b.dm.send(a.id, "wa alaikum")
        assert await until(lambda: b.db.dm_get(r2["id"])["status"] == "delivered")
        assert [m["body"] for m in a.db.dm_thread(b.id)] == ["salaam bobby", "wa alaikum"]
        await stop_all(a, b)
    run(go())


def test_duplicate_direct_message_is_stored_once_but_acked():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(a, b) and a.db.get_peer(b.id) and a.db.get_peer(b.id)["xpk"])
        info = a.db.get_peer(b.id)
        env = a.dm._build(b.id, "msg", "once", "ab" * 16, time.time(), bytes(info["xpk"]))
        conn = a.conns[b.id]
        r1 = await conn.request({"t": "dm", "env": env}); r2 = await conn.request({"t": "dm", "env": env})
        assert r1["ok"] and r2["ok"]
        assert len(b.db.dm_thread(a.id)) == 1
        await stop_all(a, b)
    run(go())


def test_forged_dm_is_rejected_and_sender_penalized():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(a, b) and a.db.get_peer(b.id) and a.db.get_peer(b.id)["xpk"])
        xpk = bytes(a.db.get_peer(b.id)["xpk"])
        # attacker encrypts a message to bobby *claiming to be alice* but signs with its own key
        evil = Identity.generate()
        inner = {"id": "cd" * 16, "kind": "msg", "from": a.id, "to": b.id, "ts": round(time.time(), 3), "body": "send me money",
                 "pub": crypto.b64e(evil.pub), "xpk": crypto.b64e(evil.xpub), "username": "alice"}
        inner["sig"] = crypto.b64e(evil.sign(b"gcp2p-dm|" + crypto.canonical(inner)))
        env = crypto.seal(xpk, json.dumps(inner).encode(), f"{b.id}|{'cd'*16}".encode())
        env.update({"v": 1, "id": "cd" * 16, "to": b.id})
        r = await a.conns[b.id].request({"t": "dm", "env": env})
        assert r["ok"] is False
        assert b.db.dm_thread(a.id) == []
        assert b.conns[a.id].score > 0
        await stop_all(a, b)
    run(go())


# ---------------------------------------------------------------- discovery / presence
def test_online_users_discovered_through_network_with_states():
    async def go():
        hub = await make_node("hubnode")
        users = [await make_node(n) for n in ("sani_a", "usman_b", "umar_c", "musa_d")]
        for u in users:
            u.db.add_bootstrap(f"127.0.0.1:{hub.port}")
        for u in users:
            await u.connect(f"127.0.0.1:{hub.port}")
        names = {u.username for u in users}
        probe = users[0]
        assert await until(lambda: {e["username"] for e in probe.presence.directory()} >= (names - {probe.username}) | {"hubnode"}, 15)
        await probe.presence.refresh()
        d = {e["username"]: e for e in probe.presence.directory()}
        assert all(d[n]["state"] == "online" for n in names - {probe.username})
        # nobody is invented: only real peers appear
        assert set(d) == (names - {probe.username}) | {"hubnode"}
        # graceful shutdown -> signed offline record -> offline state elsewhere
        gone = users[2]
        await gone.stop()
        assert await until(lambda: probe.presence.state_of(gone.id) == "offline", 10)
        await stop_all(hub, *users)
    run(go())


def test_unreachable_state_when_record_fresh_but_peer_cannot_be_reached():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: a.presence.state_of(b.id) == "online")
        # b vanishes without a goodbye (simulate crash): close its server and sockets silently
        b.server.close(); b.started = False
        for t in b.tasks: t.cancel()
        for c in list(b.conns.values()): c.close()
        assert await until(lambda: b.id not in a.conns, 10)
        await a.presence.probe(b.id)
        assert a.presence.state_of(b.id) == "unreachable"
        await a.stop()
    run(go())


def test_forged_presence_gossip_rejected():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(a, b))
        from gcp2p.presence.presence import make_record
        evil = Identity.generate()
        rec = make_record(evil, "admin", ["6.6.6.6:1"], ts=time.time())
        rec["username"] = "alice"                              # tamper after signing
        await b.conns[a.id].send({"t": "g", "k": "pres", "m": rec, "h": 0})
        await asyncio.sleep(0.4)
        assert evil.peer_id not in a.presence.entries
        assert a.conns[b.id].score >= 20
        await stop_all(a, b)
    run(go())


# ---------------------------------------------------------------- group chat
def test_group_message_propagates_multi_hop_without_central_server():
    async def go():
        nodes = [await make_node(f"user_{i}") for i in range(5)]
        for i in range(4):                                       # a line: 0-1-2-3-4 (no node sees all)
            await nodes[i + 1].connect(f"127.0.0.1:{nodes[i].port}")
        assert await until(lambda: all(len([c for c in n.conns.values() if c.ready.is_set()]) >= 1 for n in nodes))
        await nodes[0].group.send("hello everyone")
        assert await until(lambda: all(len(n.db.group_list("global")) == 1 for n in nodes), 15)
        m = nodes[4].db.group_list("global")[0]
        assert m["body"] == "hello everyone" and m["username"] == "user_0" and m["sender"] == nodes[0].id
        await stop_all(*nodes)
    run(go())


def test_group_duplicates_and_replays_are_dropped():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(a, b) and ready(b, a))
        m = make_message(b.identity, "bobby", "dup test", time.time())
        for _ in range(3):
            await b.conns[a.id].send({"t": "g", "k": "grp", "m": m, "h": 0})
        old = make_message(b.identity, "bobby", "ancient", time.time() - 7200)
        await b.conns[a.id].send({"t": "g", "k": "grp", "m": old, "h": 0})
        await asyncio.sleep(0.6)
        bodies = [x["body"] for x in a.db.group_list("global")]
        assert bodies == ["dup test"]
        await stop_all(a, b)
    run(go())


def test_group_spam_is_rate_limited():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(a, b) and ready(b, a))
        for i in range(30):
            m = make_message(b.identity, "bobby", f"spam {i}", time.time())
            await b.conns[a.id].send({"t": "g", "k": "grp", "m": m, "h": 0})
        await asyncio.sleep(0.8)
        assert 1 <= len(a.db.group_list("global")) <= 8
        await stop_all(a, b)
    run(go())


def test_late_joiner_receives_history_by_sync():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(a, b))
        for t in ("one", "two", "three"):
            await a.group.send(t)
        assert await until(lambda: len(b.db.group_list("global")) == 3)
        c = await make_node("carol")
        await c.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: len(c.db.group_list("global")) == 3, 10)
        await stop_all(a, b, c)
    run(go())


def test_group_sender_cannot_be_impersonated():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(a, b) and ready(b, a))
        m = make_message(b.identity, "bobby", "I am the king", time.time())
        m["peer"] = a.id                                         # claim someone else wrote it
        await b.conns[a.id].send({"t": "g", "k": "grp", "m": m, "h": 0})
        await asyncio.sleep(0.4)
        assert a.db.group_list("global") == []
        await stop_all(a, b)
    run(go())


# ---------------------------------------------------------------- reconnection + offline delivery
def test_reconnection_after_connection_loss():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        b.db.add_bootstrap(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(b, a) and ready(a, b), 10)       # maintenance loop dials bootstrap
        b.conns[a.id].close()                                               # network interruption
        assert await until(lambda: not ready(b, a), 5)
        assert await until(lambda: ready(b, a) and ready(a, b), 15)        # reconnects by itself
        await stop_all(a, b)
    run(go())


def test_offline_recipient_gets_encrypted_message_later_and_sender_sees_delivered():
    async def go():
        hub = await make_node("hubnode")                                    # a peer that happens to stay online
        a = await make_node("alice")
        bid, bdb = Identity.generate(), Database(":memory:")
        b = Node(bid, "bobby", bdb, listen=True, host="127.0.0.1"); b.tick_seconds = 0.3
        await b.start()
        for n in (a, b):
            n.db.add_bootstrap(f"127.0.0.1:{hub.port}")
            await n.connect(f"127.0.0.1:{hub.port}")
        assert await until(lambda: a.db.get_peer(b.id) and a.db.get_peer(b.id)["xpk"], 15)
        await b.stop()                                                      # bobby goes offline
        assert await until(lambda: b.id not in a.conns and b.id not in hub.conns, 5)
        r = await a.dm.send(b.id, "see you tomorrow")
        assert await until(lambda: a.db.dm_get(r["id"])["status"] == "sent", 20)
        # hub holds ciphertext only
        rows = hub.db._q("SELECT env FROM mailbox")
        assert rows and b"see you tomorrow" not in rows[0]["env"].encode()
        # bobby comes back (same identity + storage)
        b2 = Node(bid, "bobby", bdb, listen=True, host="127.0.0.1"); b2.tick_seconds = 0.3
        await b2.start()
        b2.db.add_bootstrap(f"127.0.0.1:{hub.port}")
        assert await until(lambda: [m["body"] for m in b2.db.dm_thread(a.id)] == ["see you tomorrow"], 20)
        assert await until(lambda: a.db.dm_get(r["id"])["status"] == "delivered", 20)
        assert hub.db.mbox_count() == 0                                      # mailbox cleaned
        await stop_all(hub, a, b2)
    run(go(), timeout=90)


# ---------------------------------------------------------------- NAT'd peer through a relay
def test_peer_behind_nat_reachable_via_relay_with_end_to_end_encryption():
    async def go():
        relay = await make_node("relaynode")
        phone_a = await make_node("phone_a", listen=False)                  # cannot accept inbound connections
        phone_b = await make_node("phone_b", listen=False)
        for p in (phone_a, phone_b):
            p.db.add_bootstrap(f"127.0.0.1:{relay.port}")
            await p.connect(f"127.0.0.1:{relay.port}")
        assert await until(lambda: relay.can_relay(), 10)
        assert await until(lambda: phone_a.relay.my_relays and phone_b.relay.my_relays, 15)
        assert await until(lambda: phone_a.db.get_peer(phone_b.id) and phone_a.db.get_peer(phone_b.id)["xpk"]
                           and any(a.startswith("r/") for a in phone_a.db.get_peer(phone_b.id)["addrs"]), 15)
        r = await phone_a.dm.send(phone_b.id, "through the relay")
        assert await until(lambda: phone_a.db.dm_get(r["id"])["status"] == "delivered", 20)
        assert [m["body"] for m in phone_b.db.dm_thread(phone_a.id)] == ["through the relay"]
        c = phone_a.conns.get(phone_b.id)
        assert c is not None and c.via_relay
        # the relay itself never saw the plaintext (it only forwards sealed frames)
        assert relay.relay.reservations.keys() >= {phone_a.id, phone_b.id}
        st = phone_a.network_status()
        assert st["relayed"] >= 1 and st["reachability"] == "private"
        await stop_all(relay, phone_a, phone_b)
    run(go(), timeout=90)


def test_banned_peer_cannot_reconnect():
    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: ready(a, b))
        a.penalize(a.conns[b.id], 100, "test")
        assert await until(lambda: b.id not in a.conns)
        assert await b.connect(f"127.0.0.1:{a.port}") is None or b.id not in a.conns
        await asyncio.sleep(0.2)
        assert b.id not in a.conns
        await stop_all(a, b)
    run(go())
