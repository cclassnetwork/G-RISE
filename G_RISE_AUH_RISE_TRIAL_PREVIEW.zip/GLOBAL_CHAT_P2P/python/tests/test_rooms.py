"""User-created groups: public (discoverable, signed) and private (invite code, encrypted)."""
import asyncio, json, time
import pytest
from helpers import run, until, make_node, stop_all
from gcp2p.group_chat import rooms as R
from gcp2p.group_chat.group import GroupError, make_message
from gcp2p.identity.identity import Identity


async def line(*names):
    nodes = [await make_node(n) for n in names]
    for i in range(len(nodes) - 1):                       # a line: 0-1-2-...  (no node sees all)
        await nodes[i + 1].connect(f"127.0.0.1:{nodes[i].port}")
    assert await until(lambda: all(any(c.ready.is_set() for c in n.conns.values()) for n in nodes))
    return nodes


def test_room_record_is_signed_and_tamper_proof():
    ident = Identity.generate()
    rec = R.make_record(ident, "Abuja Developers", "Meet and code", time.time())
    assert R.GID_RE.match(rec["gid"]) and R.verify_record(rec, time.time())
    for field, val in (("name", "Other name"), ("desc", "changed"), ("owner", "gcaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"), ("closed", True), ("ts", rec["ts"] + 1)):
        with pytest.raises(R.RoomError):
            R.verify_record(dict(rec, **{field: val}), time.time())          # nobody can edit or take over someone's group
    with pytest.raises(R.RoomError):
        R.verify_record(dict(rec, name="<b>x</b>"), time.time())
    other = Identity.generate()
    stolen = dict(rec, owner=other.peer_id, pub=R.crypto.b64e(other.pub))
    with pytest.raises(R.RoomError):
        R.verify_record(stolen, time.time())


def test_invite_codes():
    gid, key = "gr" + "a" * 20, b"k" * 32
    code = R.make_invite(gid, key, "Family chat")
    assert R.parse_invite(code) == (gid, key, "Family chat")
    for bad in ("", "x", "gcg1:" + gid, code.replace("gcg1", "zzz"), code[:-3] + "!!!", "gcg1:grBAD:" + code.split(":", 2)[2]):
        with pytest.raises(R.RoomError):
            R.parse_invite(bad)


def test_public_group_is_discovered_joined_and_chats_across_peers():
    async def go():
        a, b, c = await line("alice", "bobby", "carol")                      # alice - bobby - carol
        info = await a.rooms.create("  Abuja   Developers ", "Code together", "public")
        gid = info["gid"]
        assert info["name"] == "Abuja Developers" and info["joined"] and info["mine"] and info["kind"] == "public"
        assert await until(lambda: c.db.room_get(gid) is not None, 15)         # carol finds it through bobby (2 hops)
        row = c.db.room_get(gid)
        assert row["joined"] == 0 and row["owner"] == a.id
        listing = {r["gid"]: r for r in c.rooms.listing()}
        assert listing[gid]["joined"] is False and listing[gid]["name"] == "Abuja Developers"
        await c.rooms.join(gid)                                                  # one tap
        await a.group.send("welcome to the group", gid)
        assert await until(lambda: [m["body"] for m in c.db.group_list(gid)] == ["welcome to the group"], 15)
        await c.group.send("thanks alice", gid)
        assert await until(lambda: [m["body"] for m in a.db.group_list(gid)][-1:] == ["thanks alice"], 15)
        # bobby never joined: he forwarded but stored nothing, and nothing leaked into the global group
        assert b.db.group_list(gid) == [] and a.db.group_list("global") == [] and c.db.group_list("global") == []
        # leaving deletes local history and stops receiving
        c.rooms.leave(gid)
        assert c.db.group_list(gid) == []
        await a.group.send("after you left", gid)
        await asyncio.sleep(1)
        assert c.db.group_list(gid) == []
        with pytest.raises(GroupError):
            await c.group.send("hello?", gid)
        await stop_all(a, b, c)
    run(go(), 90)


def test_late_joiner_gets_history_and_new_peer_learns_directory_on_connect():
    async def go():
        a, b = await line("alice", "bobby")
        gid = (await a.rooms.create("Hausa Poets", "", "public"))["gid"]
        await a.group.send("first", gid); await a.group.send("second", gid)
        assert await until(lambda: b.db.room_get(gid) is not None, 15)
        d = await make_node("dan")
        await d.connect(f"127.0.0.1:{b.port}")                                   # connects later, to a non-owner
        assert await until(lambda: d.db.room_get(gid) is not None, 15)            # directory sync, no announcement needed
        await d.rooms.join(gid)
        assert await until(lambda: [m["body"] for m in d.db.group_list(gid)] == ["first", "second"] or
                           sorted(m["body"] for m in d.db.group_list(gid)) == ["first", "second"], 20)   # history by sync
        await stop_all(a, b, d)
    run(go(), 90)


def test_private_group_is_encrypted_for_forwarders_and_needs_the_invite():
    async def go():
        a, b, c, d = await line("alice", "bobby", "carol", "danny")             # a - b - c - d
        info = await a.rooms.create("Family", "", "private")
        gid, invite = info["gid"], info["invite"]
        await asyncio.sleep(1.5)
        assert all(n.db.room_get(gid) is None for n in (b, c, d))                 # not announced anywhere
        await c.rooms.join_invite(invite)
        with pytest.raises(R.RoomError):
            await b.rooms.join(gid)                                              # cannot join a private room by id
        await a.group.send("secret plan: meet at 5", gid)
        assert await until(lambda: [m["body"] for m in c.db.group_list(gid)] == ["secret plan: meet at 5"], 15)
        assert c.db.group_list(gid)[0]["username"] == "alice"
        # bobby forwarded it (carol is behind him) but holds no plaintext or history
        assert b.db.group_list(gid) == [] and d.db.group_list(gid) == []
        # on the wire the body is ciphertext and the sender name is hidden
        env = json.loads(a.db._q("SELECT raw FROM group_msgs WHERE room=?", (gid,))[0]["raw"])
        assert "secret" not in json.dumps(env) and env["username"] == "member"
        # a member's reply crosses bobby and reaches alice
        await c.group.send("ok see you", gid)
        assert await until(lambda: [m["body"] for m in a.db.group_list(gid)][-1:] == ["ok see you"], 15)
        # tampering with the ciphertext, or sending to a room with the wrong key, is dropped silently
        bad_key = await make_node("mallory")
        await bad_key.connect(f"127.0.0.1:{c.port}")
        assert await until(lambda: any(x.ready.is_set() for x in bad_key.conns.values()))
        code = R.make_invite(gid, b"x" * 32, "Family")
        await bad_key.rooms.join_invite(code)
        await bad_key.group.send("i am an intruder", gid)
        await asyncio.sleep(1.2)
        assert all("intruder" not in m["body"] for n in (a, c) for m in n.db.group_list(gid))
        assert all(x["penalty"] == 0 if "penalty" in x else True for x in [])
        await stop_all(a, b, c, d, bad_key)
    run(go(), 120)


def test_owner_can_close_public_group_and_only_the_owner():
    async def go():
        a, b = await line("alice", "bobby")
        gid = (await a.rooms.create("Short lived", "", "public"))["gid"]
        assert await until(lambda: b.db.room_get(gid) is not None, 15)
        await b.rooms.join(gid)
        with pytest.raises(R.RoomError):
            await b.rooms.close(gid)                                             # not the owner
        forged = R.make_record(b.identity, "Short lived", "", time.time() + 5, nonce=json.loads(a.db.room_get(gid)["raw"])["nonce"], closed=True)
        assert forged["gid"] != gid                                              # a different key makes a different id
        await a.rooms.close(gid)
        assert await until(lambda: b.db.room_get(gid)["closed"] == 1, 15)
        with pytest.raises(R.RoomError):
            await b.rooms.join(gid)
        with pytest.raises(GroupError):
            await b.group.send("anyone there?", gid)
        await stop_all(a, b)
    run(go(), 60)


def test_limits_and_validation():
    async def go():
        a = await make_node("alice")
        for bad in ("ab", "x" * 41, "bad<name>", "\n\n\n", 5):
            with pytest.raises(R.RoomError):
                await a.rooms.create(bad, "", "public")
        with pytest.raises(R.RoomError):
            await a.rooms.create("Fine name", "d" * 121, "public")
        with pytest.raises(R.RoomError):
            await a.rooms.create("Fine name", "", "secret-club")
        for i in range(R.MAX_OWNED):
            await a.rooms.create(f"Group number {i}", "", "private")
        with pytest.raises(R.RoomError):
            await a.rooms.create("One too many", "", "private")
        # flooding the mesh with junk room ids is rate limited and never stored if not joined
        b = await make_node("bobby"); await b.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: any(c.ready.is_set() for c in a.conns.values()))
        m = make_message(b.identity, "bobby", "spam", time.time(), room="gr" + "b" * 20)
        await b.conns[a.id].send({"t": "g", "k": "grp", "m": m, "h": 0})
        await asyncio.sleep(0.5)
        assert a.db._q("SELECT COUNT(*) c FROM group_msgs")[0]["c"] == 0
        await stop_all(a, b)
    run(go(), 60)
