import asyncio, time
from gcp2p.identity.identity import Identity
from gcp2p.networking.node import Node
from gcp2p.storage.db import Database


def run(coro, timeout=60):
    async def _w():
        return await asyncio.wait_for(coro, timeout)
    return asyncio.run(_w())


async def make_node(name, listen=True, host="127.0.0.1", **kw):
    n = Node(Identity.generate(), name, Database(":memory:"), listen=listen, host=host, **kw)
    n.tick_seconds = 0.3
    await n.start()
    return n


async def until(cond, timeout=10, step=0.05):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        r = cond()
        if asyncio.iscoroutine(r):
            r = await r
        if r:
            return True
        await asyncio.sleep(step)
    return False


async def stop_all(*nodes):
    for n in nodes:
        await n.stop()
