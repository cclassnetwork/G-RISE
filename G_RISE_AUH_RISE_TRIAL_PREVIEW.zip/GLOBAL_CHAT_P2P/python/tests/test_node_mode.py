"""The 'G-rise Node' phone app: identity + dashboard start automatically, password stays in private storage."""
import asyncio, json, os, sys, urllib.request
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from helpers import run
from gcp2p.engine import Engine
from gcp2p.api.server import ApiServer
from gcp2p.admin import server as adm
import gc_android


def test_node_mode_starts_dashboard_and_exposes_credentials_only_via_token_api(tmp_path):
    async def go():
        eng = Engine(str(tmp_path / "d"), host="127.0.0.1"); await eng.start()
        await gc_android._start_node_mode(eng, str(tmp_path / "d"))
        info = eng.node_info
        assert info["user"] == "admin" and info["url"].startswith("http://127.0.0.1:") and eng.state()["username"].startswith("node")
        pw = open(tmp_path / "d" / "node_password.txt").read().strip()
        assert pw == info["password"] and oct(os.stat(tmp_path / "d" / "node_password.txt").st_mode)[-3:] == "600"
        assert adm.check_password(pw, json.load(open(tmp_path / "d" / "admin.json"))["hash"]) and not adm.check_password("x", json.load(open(tmp_path / "d" / "admin.json"))["hash"])
        port = int(info["url"].rsplit(":", 1)[1])
        r = await asyncio.get_running_loop().run_in_executor(None, lambda: urllib.request.urlopen(f"http://127.0.0.1:{port}/admin/", timeout=5).status)
        assert r == 200
        api = ApiServer(eng, "t" * 32); ap = await api.start()
        def get(tok):
            req = urllib.request.Request(f"http://127.0.0.1:{ap}/api/node", headers={"X-GC-Token": tok})
            try: return urllib.request.urlopen(req, timeout=5).status
            except urllib.error.HTTPError as e: return e.code
        loop = asyncio.get_running_loop()
        assert await loop.run_in_executor(None, get, "t" * 32) == 200 and await loop.run_in_executor(None, get, "bad") == 401
        # restart keeps the same password
        await eng.stop()
        eng2 = Engine(str(tmp_path / "d"), host="127.0.0.1"); await eng2.start()
        await gc_android._start_node_mode(eng2, str(tmp_path / "d"))
        assert eng2.node_info["password"] == pw
        await eng2.stop()
    run(go())


def test_password_hash_falls_back_when_scrypt_is_missing(monkeypatch):
    monkeypatch.delattr(adm.hashlib, "scrypt")
    h = adm.hash_password("secret")
    assert h.startswith("pbkdf2$") and adm.check_password("secret", h) and not adm.check_password("nope", h)
