# G-rise monetization plan (NGN)

## Chosen model
- Hybrid: Free + Premium + Business + limited sponsorships.
- Display currency: Nigerian naira (NGN).
- Suggested planning prices: Premium ₦1,500/month; Business ₦5,000/month. These are placeholders to validate with users, not active store products or charges.

## What this source update does
- Adds a **Premium & Business** page under More.
- Explains proposed benefits and clearly labels prices as proposed.
- Shows a low-frequency sponsorship policy: sponsor cards only in non-chat areas; never inside DMs; never inspect message content.
- Keeps payment buttons disabled because this repository has no verified billing integration or merchant configuration.
- Fixes the Android Actions workflow to upload the `chat` and `node` flavor APKs from their actual output directories.

## What is deliberately NOT active yet
- No Google Play Billing purchase flow is connected.
- No server-side purchase-token verification is configured.
- No AdMob SDK, Ad Unit IDs, consent flow, or live ads are configured.
- No Business admin/analytics entitlements are granted by this UI.
- The proposed prices are not sent to Google Play and no one can be charged from this build.

## Required before charging users
1. Create the app in Google Play Console and configure subscriptions/products (e.g. `premium_monthly`, `business_monthly`) with NGN availability and final prices.
2. Add the Google Play Billing Library to Android and implement purchase, acknowledge, restore, and cancellation handling.
3. Verify purchase tokens using a trusted backend or a secure purchase-verification provider. Never grant Premium because of a local preference, SQLite flag, or client-only receipt.
4. Persist a signed entitlement receipt with expiry and product ID. Define grace period, refunds, chargebacks, account/device transfer, and offline expiry behavior.
5. If adding AdMob, configure app/ad unit IDs, Google UMP consent where required, child-directed treatment if relevant, and test ads first. Keep ad requests outside message content and avoid ads in chat threads.
6. Implement the paid features before enabling purchase buttons. Do not sell features that are not present.
7. Publish a privacy policy and clear subscription terms, renewal/cancellation details, support contact and refund policy.

## P2P compatibility
Messaging, identity and encryption remain peer-to-peer. Billing and ad networks are optional external commercial services and do not carry message contents. Premium verification may need internet access; offline devices should retain access to their free messaging features. A disconnected device must not be able to create or extend paid entitlements by editing local data.

## Testing checklist
- [ ] Verify chat and node variants build in GitHub Actions.
- [ ] Confirm free DMs and groups still work with no Google account / no billing connection.
- [ ] Test purchase, restore, cancellation, refund and expiry using Play test tracks.
- [ ] Confirm ads never render in DMs or private group conversations.
- [ ] Review consent and privacy disclosures before production.
